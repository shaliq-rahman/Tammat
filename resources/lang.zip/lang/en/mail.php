<?php

return [
	
	/*
	|--------------------------------------------------------------------------
	| Emails Language Lines
	|--------------------------------------------------------------------------
	|
	| The following language lines are used by the Mail notifications.
	|
	*/
	
	// mail_footer
	'mail_footer_content'            => ':appName, sell and buy near you. Simple, fast and efficient.',
	
	
	// email_verification
	'email_verification_title'       => '[:appName] Please verify your email address.',
	'email_verification_action'      => 'Verify email address',
	'email_verification_content_1'   => 'Hi :userName !',
	'email_verification_content_2'   => 'Click the button below to verify your email address.',
	'email_verification_content_3'   => 'Button not working? Paste the following link into your browser:<br><a href=":verificationLink">:verificationLink</a>.',
	'email_verification_content_4'   => '<br><br>You’re receiving this email because you recently created a new :appName account or added a new email address. If this wasn’t you, please ignore this email.',
	'email_verification_content_5'   => '<br><br>Kind Regards,<br>The :appName Team',
	
	
	// post_activated
	'post_activated_title'             => 'Your ad has been activated',
	'post_activated_content_1'         => 'Hello, <br><br>Your ad <a href=":postUrl">:title</a> has been activated.',
	'post_activated_content_2'         => '<br>It will soon be examined by one of our administrators for its publication on line.',
	'post_activated_content_3'         => '<br><br>You’re receiving this email because you recently created a new ad on :appName. If this wasn’t you, please ignore this email.',
	'post_activated_content_4'         => '<br><br>Kind Regards,<br>The :appName Team',
	
	// post_reviewed
	'post_reviewed_title'              => 'Your ad is now online',
	'post_reviewed_content_1'          => 'Hello, <br><br>Your ad <a href=":postUrl">:title</a> is now online.',
	'post_reviewed_content_2'          => '<br><br>You’re receiving this email because you recently created a new ad on :appName. If this wasn’t you, please ignore this email.',
	'post_reviewed_content_3'          => '<br><br>Kind Regards,<br>The :appName Team',
	
	
	// post_deleted
	'post_deleted_title'               => 'Your ad has been deleted',
	'post_deleted_content_1'           => 'Hello,<br><br>Your ad ":title" has been deleted from <a href=":appUrl">:appName</a> at :now.',
	'post_deleted_content_2'           => '<br><br>Thank you for your trust and see you soon,',
	'post_deleted_content_3'           => '<br><br>The :appName Team',
	'post_deleted_content_4'           => '<br><br><br>PS: This is an automated email, please don\'t reply.',
	
	
	// post_seller_contacted
	'post_seller_contacted_title'      => 'Your ad ":title" on :appName',
	'post_seller_contacted_title_delivey_info'      => 'Delivey Info ":title" on :appName',
	
	'post_seller_contacted_content_1'  => '<strong>Contact Information :</strong><br>Name : :name<br>Email address : :email<br>Phone number : :phone<br>Message : :message<br><br><strong>Delivery Preference:</strong> <br> :delivery_preference<br><br><strong>Date & Time Preference:</strong> <br> :date_time<br><br><strong>Buyer Address:</strong> <br> :buyer_address<br><br>This email was sent to you about the ad ":title" you filed on <a href=":appUrl">:appName</a> : <a href=":postUrl">:postUrl</a>',
	'post_seller_contacted_content_2'  => '<br><br>PS : The person who contacted you do not know your email as you will not reply.',
	'post_seller_contacted_content_3'  => '<br><br>Remember to always check the details of your contact person (name, address, ...) to ensure you have a contact in case of dispute. In general, choose the delivery of the item in hand.<br><br>Beware of enticing offers! Be careful with requests from abroad when you only have a contact email. The bank transfer by Western Union or MoneyGram proposed may well be artificial.',
	'post_seller_contacted_content_4'  => '<br><br>Thank you for your trust and see you soon,',
	'post_seller_contacted_content_5'  => '<br><br>The :appName Team',
	'post_seller_contacted_content_7'  => '<b><br><br>The delivery service is provided by a third party where Deal Not Deal no control over, and assumes no responsibility or liability for, the practices of any third party.<br><br>Please check the item post for to know who will be charged for the delivery cost.</b>',
	
	'post_seller_contacted_content_6'  => '<br><br><br>PS: This is an automated email, please don\'t reply.',
	
	
	// user_deleted
	'user_deleted_title'             => 'Your account has been deleted on :appName',
	'user_deleted_content_1'         => 'Hello,<br><br>Your account has been deleted from <a href=":appUrl">:appName</a> at :now.',
	'user_deleted_content_2'         => '<br><br>Thank you for your trust and see you soon,',
	'user_deleted_content_3'         => '<br><br>The :appName Team',
	'user_deleted_content_4'         => '<br><br><br>PS: This is an automated email, please don\'t reply.',
	
	
	// user_activated
	'user_activated_title'           => 'Welcome to :appName !',
	'user_activated_content_1'       => 'Welcome to :appName :userName !',
	'user_activated_content_2'       => '<br>Your account has been activated.',
	'user_activated_content_3'       => '<br><br><strong>Note : :appName team recommends that you:</strong><br><br>1 - Always beware of advertisers refusing to make you see the good offered for sale or rental,<br>2 - Never send money by Western Union or other international mandate.<br><br>If you have any doubt about the seriousness of an advertiser, please contact us immediately. We can then neutralize as quickly as possible and prevent someone less informed do become the victim.',
	'user_activated_content_4'       => '<br><br>You’re receiving this email because you recently created a new :appName account. If this wasn’t you, please ignore this email.',
	'user_activated_content_5'       => '<br><br>Kind Regards,<br>The :appName Team',
	
	
	// reset_password
	'reset_password_title'           => 'Reset Your Password',
	'reset_password_action'          => 'Reset Password',
	'reset_password_content_1'       => 'Forgot your password?',
	'reset_password_content_2'       => 'Let\'s get you a new one.',
	'reset_password_content_3'       => 'If you did not request a password reset, no further action is required.',
	'reset_password_content_4'       => '<br><br>Regards,<br>:appName',
	'reset_password_content_5'       => '<br><br>---<br>If you’re having trouble clicking the "Reset Password" button, copy and paste the URL below into your web browser:<br> :link',
	
	
	// contact_form
	'contact_form_title'             => 'New message from :appName',
	'contact_form_content'           => ':appName - New message',
	
	
	// post_report_sent
	'post_report_sent_title'           => 'New abuse report',
	'post_report_sent_content'         => 'New Report Abuse - :appName/:countryCode',
	'Post URL'                         => 'Post URL',
	
	
	// post_archived
	'post_archived_title'              => 'Your ad has been archived',
	'post_archived_content_1'          => 'Hello,<br><br>Your ad ":title" has been archived from :appName at :now.',
	'post_archived_content_2'          => '<br><br>You can repost it by clicking here : <a href=":repostLink">:repostLink</a>',
	'post_archived_content_3'          => '<br><br>If you do nothing your ad will be permanently deleted on :dateDel.',
	'post_archived_content_4'          => '<br><br>Thank you for your trust and see you soon,',
	'post_archived_content_5'          => '<br><br>The :appName Team',
	'post_archived_content_6'          => '<br><br><br>PS: This is an automated email, please don\'t reply.',
	
	
	// post_will_be_deleted
	'post_will_be_deleted_title'       => 'Your ad will be deleted in :days days',
	'post_will_be_deleted_content_1'   => 'Hello,<br><br>Your ad ":title" will be deleted in :days days from :appName.',
	'post_will_be_deleted_content_2'   => '<br><br>You can repost it by clicking here : <a href=":repostLink">:repostLink</a>',
	'post_will_be_deleted_content_3'   => '<br><br>If you do nothing your ad will be permanently deleted on :dateDel.',
	'post_will_be_deleted_content_4'   => '<br><br>Thank you for your trust and see you soon,',
	'post_will_be_deleted_content_5'   => '<br><br>The :appName Team',
	'post_will_be_deleted_content_6'   => '<br><br><br>PS: This is an automated email, please don\'t reply.',
	
	
	// post_notification
	'post_notification_title'          => 'New ad has been posted',
	'post_notification_content_1'      => 'Hello Admin,<br><br>The user :advertiserName has just posted a new ad.',
	'post_notification_content_2'      => '<br>The ad title: :title<br>Posted on: :now at :time',
	'post_notification_content_3'      => '<br><br>Kind Regards,<br>The :appName Team',
	
	
	// user_notification
	'user_notification_title'        => 'New User Registration',
	'user_notification_content_1'    => 'Hello Admin,<br><br>:name has just registered.',
	'user_notification_content_2'    => '<br>Registered on: :now at :time<br>Email: <a href="mailto::email">:email</a>',
	'user_notification_content_3'    => '<br><br>Kind Regards,<br>The :appName Team',
	
	
	// payment_sent
	'payment_sent_title'             => 'Thanks for your payment!',
	'payment_sent_content_1'         => 'Hello,<br><br>We have received your payment for the ad ":title".',
	'payment_sent_content_2'         => '<br><h1>Thank you !</h1>',
	'payment_sent_content_3'         => '<br>Kind Regards,<br>The :appName Team',
	
	
	// payment_notification
	'payment_notification_title'     => 'New payment has been sent',
	'payment_notification_content_1' => 'Hello Admin,<br><br>The user :advertiserName has just paid a package for her ad ":title".',
	'payment_notification_content_2' => '<br><br><strong>THE PAYMENT DETAILS</strong><br><strong>Reason of the payment:</strong> Ad #:adId - :packageName<br><strong>Amount:</strong> :amount :currency<br><strong>Payment Method:</strong> :paymentMethodName',
	'payment_notification_content_3' => '<br><br>Kind Regards,<br>The :appName Team',
	
	
	// reply_form
	'reply_form_title'               => ':subject',
	'reply_form_content_1'           => 'Hello,<br><br><strong>You have received a response from: :senderName. See the message below:</strong><br><br>',
	'reply_form_content_2'           => '<br><br>Kind Regards,<br>The :appName Team',


    // send offer
    'new_offer'                  =>'New Offer',
    'offer_send_1'               => 'Hello :sellername',
    'offer_send_2'               => 'You have received a response from: :buyername. See the message below:',
    'offer_send_3'               => 'You have received New Offer from :buyername',
    'offer_send_4'               => 'Related to the ad: <a href=":url">Click here to see</a>',
    'offer_send_5'               => 'Kind Regards,<br />The Deal Not Deal Team',
    
    
    // offer rejected
    'offer_rejected'               =>'Offer Rejected',
    'offer_reject_1'               => 'Hello :toname',
    'offer_reject_2'               => 'You have received a response from: :fromname. See the message below:',
    'offer_reject_3'               => 'Your offer is Rejected by :buyername',
    'offer_reject_4'               => 'Related to the ad: <a href=":url">Click here to see</a>',
    'offer_reject_5'               => 'Kind Regards,<br />The Deal Not Deal Team',
    
    
        
    // post expire
    'expire_post'               =>'Expire Post',
    'expire_post_1'               => 'Hello :toname',
    'expire_post_2'               => 'Your post has expired.',
    'expire_post_3'               => 'Post Title: :title',
    'expire_post_5'               => 'https://www.dealnotdeal.com',
    'expire_post_4'               => 'Kind Regards,<br />The Deal Not Deal Team',
    
    
    
    

];
