<?php
$advertising = \DB::table('banner')->where('banner_type', 'bottom')->where('country_code', config('country.icode'))->select('*')->first();
// $advertising = \App\Models\Advertising::where('slug', 'bottom')->first();
?>
@if (!empty($advertising))
	@include('home.inc.spacer')
	<div class="container">
	    @if(!empty($advertising->tracking_code_large))
		<div class="container hidden-md hidden-sm hidden-xs mb20 ads-parent-responsive">
			<div class="text-center">
			    <img  style="width: 100%;" src="{{ url('banner/'.$advertising->tracking_code_large) }}">
			</div>
		</div>
		@endif
		@if(!empty($advertising->tracking_code_medium))
		<div class="container hidden-lg hidden-xs mb20 ads-parent-responsive">
			<div class="text-center">
				<img  style="width: 100%;" src="{{ url('banner/'.$advertising->tracking_code_medium) }}">
			</div>
		</div>
		@endif
		@if(!empty($advertising->tracking_code_small))
		<div class="container hidden-sm hidden-md hidden-lg ads-parent-responsive">
			<div class="text-center">
			    <img  style="width: 100%;" src="{{ url('banner/'.$advertising->tracking_code_small) }}">
			</div>
		</div>
		@endif
	</div>
@endif