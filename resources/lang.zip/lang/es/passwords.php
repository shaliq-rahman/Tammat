<?php

return [
    
    /*
    |--------------------------------------------------------------------------
    | Password Reminder Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'Las contraseñas deben coincidir y contener al menos 6 caracteres',
    'reset'    => '¡Tu contraseña ha sido restablecida!',
    'sent'     => '¡Hemos enviado el enlace para reiniciar la contraseña por correo electrónico!',
    'token'    => 'El token de recuperación de contraseña es inválido.',
    'user'     => 'No pudimos encontrar a ningún usuario con ese correo electrónico.',

];
