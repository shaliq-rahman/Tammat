{{--
 * LaraClassified - Geo Classified Ads CMS
 * Copyright (c) BedigitCom. All Rights Reserved
 *
 * Website: http://www.bedigit.com
 *
 * LICENSE
 * -------
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the inclusion
 * of the above copyright notice. If you Purchased from Codecanyon,
 * Please read the full License from here - http://codecanyon.net/licenses/standard
--}}
<?php
if (auth()->check()) {
	$addmore = '#addmore';
}
else
{
	$contactMakeAnOffer = '#quickLogin';	
}

if (auth()->check()) {
	$updateoffer = '#updateoffer';
}
else
{
	$contactMakeAnOffer = '#quickLogin';	
}
?>
@extends('layouts.master')
@include('common.spacer')
@section('content')
	<div class="main-container">
		<div class="container">
			<div class="row">
				<div class="col-md-12 page-content">
					<div class="inner-box category-content">
						<h2 class="title-2">
							<strong> <i class="icon-docs"></i> {{ t('Update Offer') }}</strong> -&nbsp;
							<?php $attr = ['slug' => slugify($post->title), 'id' => $post->id]; ?>
							<a href="{{ lurl($post->uri, $attr) }}" class="tooltipHere" title="" data-placement="top"
								data-toggle="tooltip"
								data-original-title="{!! $post->title !!}">
								{!! str_limit($post->title, 45) !!}
							</a>
						</h2>
						<form class="form-horizontal" id="postForm" method="POST" action="{{ url('account/makeanoffers/storeeditoffer')}}" enctype="multipart/form-data">
							<input type="hidden" name="post-id" value="{{ $post->id }}" />
							<input type="hidden" name="makeanoffer-id" value="{{ $makeanoffer->id }}" />
								<?php

									if (!empty($picture->filename)) {
                                        $postImg = resize($picture->filename, 'medium');
                                    } else {
                                        $postImg = resize(config('larapen.core.picture.default'));
                                    }
								?>
									
								<div class="row brefcase-row">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="col-md-5 col-lg-5 col-sm-5">
											<div class="col-md-12 col-lg-12 col-sm-12">
												<div class="col-md-6 col-lg-6 col-sm-6 pull-left">
													<h1 style="text-align: center; color: #3c80af;">{{ $buyer->username }}</h1>	
												</div>
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12">
												<div class="col-md-6 col-lg-6 col-sm-6 buyer-face pull-left">	
												</div>
												<div style="margin-right: -90px;" class="col-md-6 col-lg-6 col-sm-6 brefcase-grip pull-left">
												</div>
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12 brefcase buyer">
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div id="container5" class="col-md-6 col-lg-6 col-sm-6 picture-container-up">
									        			@if(!empty($buyerProduct3))
									        			<input class="buyer-product-selected" type="hidden" name="buyer_product_3" value="{{ $buyerProduct3->id }}" />
									        			<div>
										        			<button style="color: white; background-color: #ed1c24; border-radius: 50px; padding-left: 5px; padding-right: 5px;" type="button" class="close remove-product" onclick="$(this).parent().remove();">×</button>
										        			<div class="col-md-12 col-lg-12 col-sm-12 drag">
										        				<?php

																	if (!empty($buyerProduct3->filename)) {
								                                        $postImgbuyerProduct3 = resize($buyerProduct3->filename, 'medium');
								                                    } else {
								                                        $postImgbuyerProduct3 = resize(config('larapen.core.picture.default'));
								                                    }
																?>
													            <a class="thumbnail" href="#"><img alt="" src="{{$postImgbuyerProduct3}}"></a>
													            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
													            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $buyerProduct3->title !!}">{!! $buyerProduct3->title !!}</span><br> <span>
													            		@if ($buyerProduct3->price > 0)
																		{!! \App\Helpers\Number::money($buyerProduct3->price) !!}
																		@else
																		<!--{!! \App\Helpers\Number::money(' --') !!}-->
																			{{t('Free')}}
																		@endif
																	</span>
																	</p> 
													        	</div>
													        </div>
												    	</div>
												    	@else
												    		<input class="buyer-product-selected" type="hidden" name="buyer_product_3" value="" />
												        @endif
									        		</div>
									        		<div class="col-md-6 col-lg-6 col-sm-6 picture-container-up-last">
									        			<div class="col-md-12 col-lg-12 col-sm-12">
										        			<div class="col-md-12 col-lg-12 col-sm-12 cash-heading">
												        		{{-- <label>Cash</label> --}}
												        	</div>
											        	</div>
											        	<div class="col-md-12 col-lg-12 col-sm-12">
												        	<div class="input-group offer-price">
												        		@if(auth()->user()->id != $makeanoffer->buyer_id)
																<input id="offer_price_buyer" name="offer_price_buyer" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{ $makeanoffer->offer_price }}" disabled>
																@else
																<input id="offer_price_buyer" name="offer_price_buyer" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{ $makeanoffer->offer_price }}">
																@endif
																<span class="input-group-addon">
        															{!! substr(\App\Helpers\Number::money(''), 0 , -1) !!}
    															</span>
															</div>
														</div>
									        		</div>	
									        	</div>
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div id="container1" class="col-md-6 col-lg-6 col-sm-6 picture-container-down">
									        			@if(!empty($buyerProduct1))
									        			<input class="buyer-product-selected" type="hidden" name="buyer_product_3" value="{{ $buyerProduct1->id }}" />
									        			<div>
										        			<button style="color: white; background-color: #ed1c24; border-radius: 50px; padding-left: 5px; padding-right: 5px;" type="button" class="close remove-product" onclick="$(this).parent().remove();">×</button>
										        			<div class="col-md-12 col-lg-12 col-sm-12 drag">
										        				<?php

																	if (!empty($buyerProduct1->filename)) {
								                                        $postImgbuyerProduct1 = resize($buyerProduct1->filename, 'medium');
								                                    } else {
								                                        $postImgbuyerProduct1 = resize(config('larapen.core.picture.default'));
								                                    }
																?>
													            <a class="thumbnail" href="#"><img alt="" src="{{$postImgbuyerProduct1}}"></a>
													            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
													            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $buyerProduct1->title !!}">{!! $buyerProduct1->title !!}</span><br> <span>
													            		@if ($buyerProduct1->price > 0)
																		{!! \App\Helpers\Number::money($buyerProduct1->price) !!}
																		@else
																		<!--{!! \App\Helpers\Number::money(' --') !!}-->
																			{{t('Free')}}
																		@endif
																	</span>
																	</p> 
													        	</div>
													        </div>
												    	</div>
												    	@else
												    		<input class="buyer-product-selected" type="hidden" name="buyer_product_3" value="" />
												        @endif
									        		</div>
									        		<div id="container2" class="col-md-6 col-lg-6 col-sm-6 picture-container-down-last">
									        			
									        			@if(!empty($buyerProduct2))
									        			<input class="buyer-product-selected" type="hidden" name="buyer_product_2" value="{{ $buyerProduct2->id }}" />
									        			<div>
										        			<button style="color: white; background-color: #ed1c24; border-radius: 50px; padding-left: 5px; padding-right: 5px;" type="button" class="close remove-product" onclick="$(this).parent().remove();">×</button>
										        			<div class="col-md-12 col-lg-12 col-sm-12 drag">
										        				<?php

																	if (!empty($buyerProduct2->filename)) {
								                                        $postImgbuyerProduct2 = resize($buyerProduct2->filename, 'medium');
								                                    } else {
								                                        $postImgbuyerProduct2 = resize(config('larapen.core.picture.default'));
								                                    }
																?>
													            <a class="thumbnail" href="#"><img alt="" src="{{$postImgbuyerProduct2}}"></a>
													            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
													            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $buyerProduct2->title !!}">{!! $buyerProduct2->title !!}</span><br> <span>
													            		@if ($buyerProduct2->price > 0)
																		{!! \App\Helpers\Number::money($buyerProduct2->price) !!}
																		@else
																		<!--{!! \App\Helpers\Number::money(' --') !!}-->
																			{{t('Free')}}
																		@endif
																	</span>
																	</p> 
													        	</div>
													        </div>
												    	</div>
												    	@else
												    	<input class="buyer-product-selected" type="hidden" name="buyer_product_2" value="" />
												        @endif
									        		</div>	
									        	</div>	
											</div>	
											{{-- <div class="container">
											  <div class='row'> --}}
											    <div class="col-md-12 product-carousel">
											      <div class="carousel slide media-carousel" id="media1">
											        <div class="carousel-inner buyer-carousel">
											        <?php  $j = 0 ;?>
											        @foreach($buyerPosts->unique('id') as $buyerPost)
											        <?php

														if (!empty($picture->filename)) {
					                                        $postproductImg = resize($buyerPost->filename, 'medium');
					                                    } else {
					                                        $postproductImg = resize(config('larapen.core.picture.default'));
					                                    }
													?>
													
													<div id="drag<?=$j ?>" class="col-md-4 drag buyer-drag-product">
										                <a class="thumbnail" href="{{ lurl('/').'/'.slugify($buyerPost->title).'/'.$buyerPost->id }}" target="_blank"><img alt="" src="{{ $postproductImg }}"></a>
										                <input class="buyer-product" type="hidden" name="buyer_product" value="{{ $buyerPost->id }}" />
										                <div class="col-md-12 col-lg-12 col-sm-12 product-name">
										                	<p class="product-name-data">
										                		<span>
										                			{!! $buyerPost->title !!}
										                		</span>
										                		<br>
										                		<span>
											                		@if ($buyerPost->price > 0)
																	{!! \App\Helpers\Number::money($buyerPost->price) !!}
																	@else
																	<!--{!! \App\Helpers\Number::money(' --') !!}-->
																		{{t('Free')}}
																	@endif
										                		</span>
										                	</p> 
										                </div>	
										             </div>
											           
											        <?php  $j++;?>
											        @endforeach
											        </div>
											        @if($buyerPosts->unique('id')->count() > 3)
												        <a data-slide="prev" href="#media1" class="left carousel-control">‹</a>
												        <a data-slide="next" href="#media1" class="right carousel-control">›</a>
												    @endif    
											      </div>                          
											    </div>
											    <div class="col-md-12 product-model-button hide">
											    	<div class="row">
											    		<div class="col-md-12 col-lg-12 col-sm-12">
											    			<button class="btn btn-primary col-md-12 col-lg-12 col-sm-12">Add Products</button>
											    		</div>	
											    	</div>	
											    </div>    
											  {{-- </div>
											</div> --}}
											
										</div>	
										<div class="col-md-2 col-lg-2 col-sm-2 offer-arrow">
											<div class="col-md-12">
										    	<div class="row">
									    			@if(auth()->user()->user_type_id == 3)
									    			<div class="form-group">
									    				@if(auth()->user()->id != $makeanoffer->offer_maker_id || $makeanoffer->approve_seller == 1 || $makeanoffer->approve_seller == 2)
										    				@if($makeanoffer->approve_seller == 1)
										    					<div class="col-md-12 col-lg-12 col-sm-12">
										    						{{-- @if($makeanoffer->offer_maker_id == auth()->user()->id) --}}
										    						<a href="#buyNow" data-toggle="modal" class="btn btn-danger btn-block">
																	<i class="glyphicon glyphicon-shopping-cart"></i> {{ t('Buy Now') }}</a>	
										    						{{-- @else
											    						<button class="btn btn-primary col-md-12 col-lg-12 col-sm-12" disabled>Deal!</button>
																	@endif --}}
										    					</div>
										    				@else
										    				<div class="col-md-12 col-lg-12 col-sm-12">
												    			@if($makeanoffer->approve_seller == 2)
												    				<button type="submit" class="btn btn-success col-md-12 col-lg-12 col-sm-12">Send Offer</button>	
												    			@else
												    			<a href="{{lurl('account/makeanoffers/'.$makeanoffer->post_id.'/dealseller/'. $makeanoffer->id)}}" class="btn btn-success col-md-12 col-lg-12 col-sm-12">Accept</a>
												    			@endif
											    			</div>
												    		<div class="col-md-12 col-lg-12 col-sm-12">
												    			@if($makeanoffer->approve_seller == 2)
												    				<button class="btn btn-danger col-md-12 col-lg-12 col-sm-12" disabled>Rejected</button>
												    			@else
												    				<a href="{{lurl('account/makeanoffers/'.$makeanoffer->post_id.'/notdealseller/'. $makeanoffer->id)}}" class="btn btn-danger col-md-12 col-lg-12 col-sm-12">Reject</a>
												    			@endif
												    		</div>
												    		@endif
									    				@else
									    					<div class="col-md-12 col-lg-12 col-sm-12">
									    						<button class="btn btn-default col-md-12 col-lg-12 col-sm-12" disabled>Awaiting Response</button>
									    					</div>
									    				@endif	
									    			</div>
									    			@endif
									    		</div>	
										    </div>
										    @if(auth()->user()->user_type_id == 2)
											<div class="col-md-12">
										    	<div class="row">
										    		@if(auth()->user()->id != $makeanoffer->offer_maker_id || $makeanoffer->approve_seller == 1 || $makeanoffer->approve_seller == 2)
										    			@if($makeanoffer->approve_seller == 1)
									    					<div class="col-md-12 col-lg-12 col-sm-12">
									    						{{-- @if($makeanoffer->offer_maker_id == auth()->user()->id)
										    						<a href="#buyNow" data-toggle="modal" class="btn btn-danger btn-block">
																	<i class="glyphicon glyphicon-shopping-cart"></i> {{ t('Buy Now') }}</a>	
									    						@else --}}
										    						<button class="btn btn-primary col-md-12 col-lg-12 col-sm-12" disabled>Deal!</button>
																{{-- @endif --}}
									    					</div>
									    				@else
									    				<div class="col-md-12 col-lg-12 col-sm-12">
											    			@if($makeanoffer->approve_seller == 2)
											    				<button type="submit" class="btn btn-success col-md-12 col-lg-12 col-sm-12">Send Offer</button>	
											    			@else
											    			<a href="{{lurl('account/makeanoffers/'.$makeanoffer->post_id.'/dealseller/'. $makeanoffer->id)}}" class="btn btn-success col-md-12 col-lg-12 col-sm-12">Accept</a>
											    			@endif
										    			</div>
											    		<div class="col-md-12 col-lg-12 col-sm-12">
											    			@if($makeanoffer->approve_seller == 2)
											    				<button class="btn btn-danger col-md-12 col-lg-12 col-sm-12" disabled>Rejected</button>
											    			@else
											    				<a style="margin-top: 10px;" href="{{lurl('account/makeanoffers/'.$makeanoffer->post_id.'/notdealseller/'. $makeanoffer->id)}}" class="btn btn-danger col-md-12 col-lg-12 col-sm-12">Reject</a>
											    			@endif
											    		</div>
											    		@endif
										    		@else
								    					<div class="col-md-12 col-lg-12 col-sm-12">
								    						<button class="btn btn-default col-md-12 col-lg-12 col-sm-12" disabled>Awaiting Response</button>
								    					</div>
										    		@endif	
										    	</div>	
										    </div>
										    @endif
										</div>
										<div class="col-md-5 col-lg-5 col-sm-5">
											<div class="col-md-12 col-lg-12 col-sm-12">
												<div class="col-md-6 col-lg-6 col-sm-6 pull-right">
													<h1 style="text-align: center; color: #3c80af;">{{$seller->username}}</h1>
												</div>
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12">
												<div class="col-md-6 col-lg-6 col-sm-6 seller-face pull-right">	
												</div>
												<div style="margin-left: -90px;" class="col-md-6 col-lg-6 col-sm-6 brefcase-grip pull-right">
												</div>
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12 brefcase seller">
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div class="col-md-6 col-lg-6 col-sm-6 picture-container-up">
									        			<div class="col-md-12 col-lg-12 col-sm-12">
												            <a class="thumbnail" href="#"><img alt="" src="{{$postImg}}"></a>

												            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
												            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $post->title !!}">{!! $post->title !!}</span><br> 
												            	<span>
												            		@if ($post->price > 0)
																	{!! \App\Helpers\Number::money($post->price) !!}
																	@else
																	<!--{!! \App\Helpers\Number::money(' --') !!}-->
																		{{t('Free')}}
																	@endif
												            	</span>
												            	</p>
												        	</div>
												        </div>
									        		</div>
									        		<div class="col-md-6 col-lg-6 col-sm-6 picture-container-up-last">
									        			<div class="col-md-12 col-lg-12 col-sm-12">
										        			<div class="col-md-12 col-lg-12 col-sm-12 cash-heading">
												        		{{-- <label>Cash</label> --}}
												        	</div>
											        	</div>
											        	<div class="col-md-12 col-lg-12 col-sm-12">
												        	<div class="input-group offer-price">
												        		@if(auth()->user()->id != $makeanoffer->seller_id)
																<input id="offer_price_seller" name="offer_price_seller" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{$makeanoffer->original_price}}" disabled>
																@else
																<input id="offer_price_seller" name="offer_price_seller" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{ $makeanoffer->original_price }}">
																@endif
																<span class="input-group-addon">
        															{!! substr(\App\Helpers\Number::money(''), 0 , -1) !!}
    															</span>
															</div>
														</div>
									        		</div>	
									        	</div>
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div id="container3" class="col-md-6 col-lg-6 col-sm-6 picture-container-down">
									        			@if(!empty($sellerProduct1))
									        			<input class="seller-product-selected" type="hidden" name="seller_product_1" value="{{ $sellerProduct1->id }}" />
									        			<div>
										        			<button style="color: white; background-color: #ed1c24; border-radius: 50px; padding-left: 5px; padding-right: 5px;" type="button" class="close remove-product" onclick="$(this).parent().remove();">×</button>
										        			<div class="col-md-12 col-lg-12 col-sm-12 drag">
										        				<?php

																	if (!empty($sellerProduct1->filename)) {
								                                        $postImgsellerProduct1 = resize($sellerProduct1->filename, 'medium');
								                                    } else {
								                                        $postImgsellerProduct1 = resize(config('larapen.core.picture.default'));
								                                    }
																?>
													            <a class="thumbnail" href="#"><img alt="" src="{{$postImgsellerProduct1}}"></a>
													            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
													            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $sellerProduct1->title !!}">{!! $sellerProduct1->title !!}</span><br> <span>
													            		@if ($sellerProduct1->price > 0)
																		{!! \App\Helpers\Number::money($sellerProduct1->price) !!}
																		@else
																		<!--{!! \App\Helpers\Number::money(' --') !!}-->
																			{{t('Free')}}
																		@endif
																	</span>
																	</p> 
													        	</div>
													        </div>
													    </div>
													    @else
													    	<input class="seller-product-selected" type="hidden" name="seller_product_1" value="" />    
												        @endif
									        		</div>
									        		<div id="container4" class="col-md-6 col-lg-6 col-sm-6 picture-container-down-last">
									        			@if(!empty($sellerProduct2))
									        			<input class="seller-product-selected" type="hidden" name="seller_product_2" value="{{ $sellerProduct2 ->id}}" />
									        			<div>
										        			<button style="color: white; background-color: #ed1c24; border-radius: 50px; padding-left: 5px; padding-right: 5px;" type="button" class="close remove-product" onclick="$(this).parent().remove();">×</button>
										        			<div class="col-md-12 col-lg-12 col-sm-12 drag">
										        				<?php

																	if (!empty($sellerProduct2->filename)) {
								                                        $postImgsellerProduct2 = resize($sellerProduct2->filename, 'medium');
								                                    } else {
								                                        $postImgsellerProduct2 = resize(config('larapen.core.picture.default'));
								                                    }
																?>
													            <a class="thumbnail" href="{{ lurl('/').'/'.slugify($sellerPost->title).'/'.$sellerPost->id }}" target="_blank"><img alt="" src="{{$postImgsellerProduct2}}"></a>
													            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
													            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $sellerProduct2->title !!}">{!! $sellerProduct2->title !!}</span><br> <span>
													            		@if ($sellerProduct1->price > 0)
																		{!! \App\Helpers\Number::money($sellerProduct2->price) !!}
																		@else
																		<!--{!! \App\Helpers\Number::money(' --') !!}-->
																			{{t('Free')}}
																		@endif
																	</span>
																	</p> 
													        	</div>
													        </div>
													    </div>
													    @else
													    <input class="seller-product-selected" type="hidden" name="seller_product_2" value="" />    
												        @endif
									        		</div>	
									        	</div>	
											</div>
											{{-- <div class="container">
											  <div class='row'> --}}
											    <div class="col-md-12 product-carousel">
											      <div class="carousel slide media-carousel" id="media">
											        <div class="carousel-inner seller-carousel">
											        <?php  $j = 0 ;?>
											        @foreach($sellerPosts->unique('id') as $sellerPost)
											        <?php

														if (!empty($picture->filename)) {
					                                        $postproductImg = resize($sellerPost->filename, 'medium');
					                                    } else {
					                                        $postproductImg = resize(config('larapen.core.picture.default'));
					                                    }
													?>
													
													<div id="drag<?=$j ?>" class="col-md-4 drag seller-drag-product">
										                <a class="thumbnail" href="#"><img alt="" src="{{ $postproductImg }}"></a>
										                <input class="seller-product" type="hidden" name="seller_product" value="{{ $sellerPost->id }}" />
										                <div class="col-md-12 col-lg-12 col-sm-12 product-name">

										                	<p class="product-name-data">
										                		<span>
										                			{!! $sellerPost->title !!}
										                		</span>
										                		<br>
										                		<span>
											                		@if ($sellerPost->price > 0)
																	{!! \App\Helpers\Number::money($sellerPost->price) !!}
																	@else
																	<!--{!! \App\Helpers\Number::money(' --') !!}-->
																		{{t('Free')}}
																	@endif
										                		</span>
										                	</p> 
										                </div>	
										             </div>
											           
											        <?php  $j++;?>
											        @endforeach
											        
											        </div>
											        @if($sellerPosts->unique('id')->count() > 3)
												        <a data-slide="prev" href="#media" class="left carousel-control">‹</a>
												        <a data-slide="next" href="#media" class="right carousel-control">›</a>
												    @endif
											      </div>                          
											    </div>
											    <div class="col-md-12 product-model-button hide">
											    	<div class="row">
											    		<div class="col-md-12 col-lg-12 col-sm-12">
											    			<button class="btn btn-primary col-md-12 col-lg-12 col-sm-12">Add Products</button>
											    		</div>	
											    	</div>	
											    </div>
											  {{-- </div>
											</div> --}}
										</div>
									</div>
								</div>
								{{-- <div class="row desktop-button">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="col-md-4 col-lg-4 col-sm-4">
										</div>
										<div class="col-md-4 col-lg-4 col-sm-4 button-send-offer-div">
											<button class="btn btn-success col-md-10 col-lg-10 col-sm-10 button-send-offer ">Send Offer</button>
										</div>
										<div class="col-md-4 col-lg-4 col-sm-4">
										</div>
									</div>
								</div> --}}

								{{-- <div class="col-md-12 button-send-offer-div-mobile hide">
							    	<div class="row">
							    		<div class="col-md-12 col-lg-12 col-sm-12">
							    			<button class="btn btn-success col-md-12 col-lg-12 col-sm-12">Send Offer</button>
							    		</div>	
							    	</div>	
							    </div> --}}
						</form>	
					</div>
				</div>
			</div>
		</div>
	</div>	
@endsection

@section('after_styles')
	@include('layouts.inc.tools.wysiwyg.css')
@endsection
@section('modal_message')
	@if (auth()->check())
		@include('post.inc.buymessage') 
	@endif
@endsection
{{-- @section('add_more')
	@if (auth()->check() or config('settings.single.guests_can_contact_seller')=='1')
		@include('account.inc.add-more', array('all_post' => $all_post, 'makeanoffers' => $makeanoffers ))
	@endif
@endsection --}}

{{-- @section('update_offer')
	@if (auth()->check() or config('settings.single.guests_can_contact_seller')=='1')
		@include('account.inc.update-offer', array('all_post' => $all_post, 'makeanoffers' => $makeanoffers ))
	@endif
@endsection --}}
