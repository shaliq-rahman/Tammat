<?php

return [
    
    /*
    |--------------------------------------------------------------------------
    | Password Reminder Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */
    
    'password' => 'A palavra-passe deve ter pelo menos seis caracteres.' ,
    'reset'    => 'A palavra-passe foi redefinida!',
    'sent'     => 'O lembrete para a palavra-passe foi enviado!',
    'token'    => 'Este código de recuperação da palavra-passe é inválido.',
    'user'     => 'Não existe nenhum utilizador com o endereço de correio eletrónico indicado.',

];
