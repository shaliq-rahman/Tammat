<?php
$advertising = \DB::table('banner')->where('banner_type', 'top')->where('country_code', config('country.icode'))->select('*')->get();
// $advertising = \App\Models\Advertising::where('slug', 'top')->first();
?>
@if (!empty($advertising))
	@include('home.inc.spacer')
	<div class="container">
@if(!empty($advertising))	    
<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->


    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        <?php
        $ad_i = 0;
        ?>
    @foreach($advertising as $ad_value)
    <?php
        $ad_active = '';
        if($ad_i == 0)
        {
            $ad_active = 'active';
            $ad_i++;
        }
    ?>
      <div class="item <?=$ad_active?>">
        <img src="https://www.dealnotdeal.com/banner/5b9656dd741af_1536579293_20180910.jpg" alt="Los Angeles" style="width:100%;">
      </div>
    @endforeach
      
    </div>

    
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
    
  </div>
  
@endif
  
  
  
  
  
	 <!--   @if(!empty($advertising->tracking_code_large))-->
		<!--<div class="container hidden-md hidden-sm hidden-xs ads-parent-responsive">-->
		<!--	<div class="text-center">-->
		<!--		<img  style="width: 100%" src="{{ url('banner/'.$advertising->tracking_code_large) }}">-->
		<!--	</div>-->
		<!--</div>-->
		<!--@endif-->
		<!--@if(!empty($advertising->tracking_code_medium))-->
		<!--<div class="container hidden-lg hidden-xs ads-parent-responsive">-->
		<!--	<div class="text-center">-->
		<!--		<img  style="width: 100%;" src="{{ url('banner/'.$advertising->tracking_code_medium) }}">-->
		<!--	</div>-->
		<!--</div>-->
		<!--@endif-->
		<!--@if(!empty($advertising->tracking_code_small))-->
		<!--<div class="container hidden-sm hidden-md hidden-lg ads-parent-responsive">-->
		<!--	<div class="text-center">-->
		<!--		<img  style="width: 100%;" src="{{ url('banner/'.$advertising->tracking_code_small) }}">-->
		<!--	</div>-->
		<!--</div>-->
		<!--@endif-->
	</div>
@endif
