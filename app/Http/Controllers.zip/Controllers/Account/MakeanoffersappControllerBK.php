<?php
/**
 * LaraClassified - Geo Classified Ads Software
 * Copyright (c) BedigitCom. All Rights Reserved
 *
 * Website: http://www.bedigit.com
 *
 * LICENSE
 * -------
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the inclusion
 * of the above copyright notice. If you Purchased from Codecanyon,
 * Please read the full License from here - http://codecanyon.net/licenses/standard
 */

namespace App\Http\Controllers\Account;

use App\Http\Controllers\FrontController;
use Torann\LaravelMetaTags\Facades\MetaTag;
use App\Models\Makeanoffer;
use App\Models\Post;
use App\Models\Picture;
use App\Http\Requests\MakeAnOfferEditRequest;
use App\Http\Requests\MakeAnOfferRequest;
// use Illuminate\Support\Facades\Request;
use Illuminate\Http\Request;
use DB;
use App\Models\User;
use App\Notifications\SellerContacted;
use App\Models\Scopes\VerifiedScope;
use App\Models\Scopes\ReviewedScope;
use App\Helpers\Localization\Helpers\Country as CountryLocalizationHelper;
use App\Helpers\Localization\Country as CountryLocalization;
use App\PushNotification\firebase;
use App\PushNotification\push;

class MakeanoffersappController extends AccountappBaseController
{
	private $perPage = 10;
	
	public function __construct()
	{
		//parent::__construct();
		
		//$this->perPage = (is_numeric(config('settings.listing.items_per_page'))) ? config('settings.listing.items_per_page') : $this->perPage;
	}
	
	/**
	 * List Transactions
	 *
	 * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
	 */
	public function index(Request $request) 
	{		
	    
	   
		$seller_id = $request->userid;
        $buyer_id = $request->userid;
        //$receiverId = $request->receiverId;
       // $receivers = DB::table('users')->where('id', '=',$receiverId)->get();
        $users = DB::table('users')->where('id', '=',$seller_id)->get();
        foreach($users as $user){
           $title = $user->name.'has send you an offer';
        }
        $status = 1;
		$makeanoffers =  Makeanoffer::where(function ($query) use ($seller_id, $buyer_id, $status)
        {
            $query->where('makeanoffers.buyer_id', $seller_id)->orWhere('makeanoffers.seller_id', $seller_id);
            $query->where('makeanoffers.status', '=', $status);
        })
        
        ->with('buyer_info:id,username,created_at')
        ->with('seller_info:id,username,created_at')
        
        ->with(['buyer_product_1_object' => function ($builder) {
            $builder->select('id','title','created_at','price');
            $builder->with(['picture_single']);
        }])
        
        ->with(['buyer_product_2_object' => function ($builder) {
            $builder->select('id','title','created_at','price');
            $builder->with(['picture_single']);
        }])
        
        ->with(['buyer_product_3_object' => function ($builder) {
            $builder->select('id','title','created_at','price');
            $builder->with(['picture_single']);
        }])

        ->with(['seller_product_1_object' => function ($builder) {
            $builder->select('id','title','created_at','price');
            $builder->with(['picture_single']);
        }])
        
        ->with(['seller_product_2_object' => function ($builder) {
            $builder->select('id','title','created_at','price');
            $builder->with(['picture_single']);
        }])
        
        ->with(['post_id_object' => function ($builder) {
            $builder->select('id','title','created_at','price');
            $builder->with(['picture_single']);
        }])
        
        ->join('posts', 'makeanoffers.post_id', '=', 'posts.id')
        ->select('makeanoffers.*', 'posts.country_code' , 'posts.user_id', 'posts.category_id', 'posts.post_type_id', 'posts.title', 'posts.description', 'posts.tags', 'posts.price', 'posts.negotiable', 'posts.contact_name', 'posts.email', 'posts.phone', 'posts.phone_hidden', 'posts.address', 'posts.city_id', 'posts.lon', 'posts.lat', 'posts.ip_addr', 'posts.visits', 'posts.email_token', 'posts.phone_token', 'posts.tmp_token', 'posts.verified_email', 'posts.verified_phone', 'posts.reviewed', 'posts.featured', 'posts.archived', 'posts.fb_profile', 'posts.partner')  
            ->orderByDesc('makeanoffers.id');
        
		$num = $makeanoffers->count();
		$data = $makeanoffers->paginate(10);
		


		return response()->json(['status'=>1,'message'=>'success','results'=>$data,'num'=>$num]);
	}
	
	public function getOffer(Request $request) 
	{		
		$seller_id = $request->userid;
        $buyer_id = $request->userid;
        $status = 1;

		$makeanoffers =  DB::table('makeanoffers')->where(function ($query) use ($seller_id, $buyer_id, $status)
        {
            $query->where('makeanoffers.buyer_id', $seller_id)->orWhere('makeanoffers.seller_id', $seller_id);
            $query->where('makeanoffers.status', '=', $status);
        })
        ->join('posts', 'makeanoffers.post_id', '=', 'posts.id')
        ->select('makeanoffers.*', 'posts.country_code' , 'posts.user_id', 'posts.category_id', 'posts.post_type_id', 'posts.title', 'posts.description', 'posts.tags', 'posts.price', 'posts.negotiable', 'posts.contact_name', 'posts.email', 'posts.phone', 'posts.phone_hidden', 'posts.address', 'posts.city_id', 'posts.lon', 'posts.lat', 'posts.ip_addr', 'posts.visits', 'posts.email_token', 'posts.phone_token', 'posts.tmp_token', 'posts.verified_email', 'posts.verified_phone', 'posts.reviewed', 'posts.featured', 'posts.archived', 'posts.fb_profile', 'posts.partner',\DB::raw('(SELECT pictures.filename FROM pictures WHERE pictures.post_id = makeanoffers.post_id AND pictures.position = 1 ) AS image'))  
            ->orderByDesc('makeanoffers.id');
        var_dump($makeanoffers);
        die();
		$num = $makeanoffers->count();
		$data = $makeanoffers->get();
		
		$payload = array();
		
		foreach($data as $value)
		{
		    $json['id'] = $value->id;
		    $json['post_id'] = $value->post_id;
		    $json['buyer_product_1'] = $value->buyer_product_1;
		    $json['buyer_product_2'] = $value->buyer_product_2;
		    $json['buyer_product_3'] = $value->buyer_product_3;
		    $json['seller_product_1'] = $value->seller_product_1;
		    $json['seller_product_2'] = $value->seller_product_2;
		    $json['original_price'] = $value->original_price;
		    $json['offer_price'] = $value->offer_price;
		    $json['description_text'] = $value->description_text;
		    $json['buyer_id'] = $value->buyer_id;
		    $json['seller_id'] = $value->seller_id;
		    $json['is_read_admin'] = $value->is_read_admin;
		    $json['is_read_professional'] = $value->is_read_professional;
		    
		    $json['is_read_individual'] = $value->is_read_individual;
		    $json['approve_seller'] = $value->approve_seller;
		    $json['approve_buyer'] = $value->approve_buyer;
		    $json['approve_admin'] = $value->approve_admin;
		    $json['status'] = $value->status;
		    $json['created_at'] = $value->created_at;
		    $json['updated_at'] = $value->updated_at;
		    $json['offer_parent'] = $value->offer_parent;
		    $json['offer_maker_id'] = $value->offer_maker_id;
		    $json['close_offer'] = $value->close_offer;
		    
		    $json['is_read'] = $value->is_read;
		    $json['counter_offer'] = $value->counter_offer;
		    $json['user_id'] = $value->user_id;
		    $json['category_id'] = $value->category_id;
		    $json['post_type_id'] = $value->post_type_id;
		    $json['title'] = $value->title;
		    $json['description'] = $value->description;
		    $json['tags'] = $value->tags;
		    $json['price'] = $value->price;
		    $json['negotiable'] = $value->negotiable;
		    
		    $json['contact_name'] = $value->contact_name;
		    $json['email'] = $value->email;
		    $json['phone'] = $value->phone;
		    $json['phone_hidden'] = $value->phone_hidden;
		    $json['address'] = $value->address;
		    
		    $json['city_id'] = $value->city_id;
		    $json['lon'] = $value->lon;
		    $json['lat'] = $value->lat;
		    $json['ip_addr'] = $value->ip_addr;
		    $json['visits'] = $value->visits;
		    $json['email_token'] = $value->email_token;
		    
		    $json['phone_token'] = $value->phone_token;
		    $json['tmp_token'] = $value->tmp_token;
		    $json['verified_email'] = $value->verified_email;
		    $json['verified_phone'] = $value->verified_phone;
		    $json['reviewed'] = $value->reviewed;
		    $json['featured'] = $value->featured;
		    $json['archived'] = $value->archived;
		    $json['fb_profile'] = $value->fb_profile;
		    $json['partner'] = $value->partner;
		    
		    if(!empty($value->image))
		    {
		        	$postImg = resize($value->image, 'medium');
		    }
		    else
		    {
	        	$postImg = resize(config('larapen.core.picture.default'));
		    }
		    
		    
		    $json['image'] = $postImg;
			
			if(!empty($value->buyer_id))
			{
			$user = User::findorfail($value->buyer_id);
			$json['from'] = $user->username;
			}
			else
			{
			$json['from'] = '';
			}
			
			if(!empty($value->seller_id))
			{
			$user1 = User::findorfail($value->seller_id);			
			$json['to'] = $user1->username;
			}
			else
			{
			$json['to'] = '';
			}
			
			$json['created_at_app'] = date('d F Y H:i',strtotime($value->created_at));
		  var_dump($json);
		  die();
		  $payload[] =  $json;
		}
		
		
		
		
		return response()->json(['results'=>$payload,'num'=>$num]);
	}
	
	
	
	
	

	public function makeanoffer($id, Request $request)
	{	
		$makeanoffer = Makeanoffer::where(['post_id' => $id , 'status' => 1 , 'offer_parent' => 0])->first();
		if(empty($makeanoffer))
		{
			$data = [];
			$data['makeanoffer'] = $makeanoffer;
			$data['post'] = Post::findOrFail($id);
			$data['picture'] = Picture::where(['post_id' => $data['post']['id'] , 'position' => 1])->first();
			// if(auth()->user()->user_type_id == 2)
			// {

			// }
			// else
			// {

			// }
			
			$data['buyer'] = User::where(['id' => $request->userid])->first();
			$data['seller'] = User::where(['id' => $data['post']['user_id']])->first();
			$seller_id = $data['seller']['id'];
			$buyer_id = $data['buyer']['id'];
			$data['sellerPosts'] = DB::table('posts')->where(function ($query) use ($seller_id, $id)
	        {
	            $query->where('posts.user_id', '=', $seller_id);
	            $query->where('posts.id', '!=', $id);
	            $query->where('posts.reviewed', '=', 1);
	            $query->where('posts.archived', '=', 0);
	        })
			->join('pictures', 'posts.id', '=', 'pictures.post_id')
			->where('pictures.position' , 1)
	        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->get();

			$data['buyerPosts'] = DB::table('posts')->where(function ($query) use ($buyer_id)
	        {
	            $query->where('posts.user_id', '=', $buyer_id);
	            $query->where('posts.reviewed', '=', 1);
	            $query->where('posts.archived', '=', 0);

	        })
			->join('pictures', 'posts.id', '=', 'pictures.post_id')
	        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->get();
			
			return $data;
		}
		else
		{
			$data = [];
			$data['makeanoffer'] = Makeanoffer::where(['post_id' => $id , 'status' => 1])->first();
			$data['post'] = Post::findOrFail($id);
			$data['picture'] = Picture::where(['post_id' => $data['post']['id'] , 'position' => 1])->first();
			$data['buyer'] = User::where(['id' => $data['makeanoffer']['buyer_id']])->first();
			$data['seller'] = User::where(['id' => $data['makeanoffer']['seller_id']])->first();
			$seller_id = $data['seller']['id'];
			$buyer_id = $data['buyer']['id'];
			$buyer_product_1 = $data['makeanoffer']['buyer_product_1'];
			$buyer_product_2 = $data['makeanoffer']['buyer_product_2'];
			$buyer_product_3 = $data['makeanoffer']['buyer_product_3'];
			$seller_product_1 = $data['makeanoffer']['seller_product_1'];
			$seller_product_2 = $data['makeanoffer']['seller_product_2'];
			if(!empty($buyer_product_1))
			{
				$data['buyerProduct1'] = DB::table('posts')->where(function ($query) use ($buyer_product_1)
		        {
		            $query->where('posts.id', '=', $buyer_product_1);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			}

			if(!empty($buyer_product_2))
			{
				$data['buyerProduct2'] = DB::table('posts')->where(function ($query) use ($buyer_product_2)
		        {
		            $query->where('posts.id', '=', $buyer_product_2);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			}

			if(!empty($buyer_product_3))
			{
				$data['buyerProduct3'] = DB::table('posts')->where(function ($query) use ($buyer_product_3)
		        {
		            $query->where('posts.id', '=', $buyer_product_3);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			}

			if(!empty($seller_product_1))
			{
				$data['sellerProduct1'] = DB::table('posts')->where(function ($query) use ($seller_product_1)
		        {
		            $query->where('posts.id', '=', $seller_product_1);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			}

			if(!empty($seller_product_2))
			{
				$data['sellerProduct2'] = DB::table('posts')->where(function ($query) use ($seller_product_2)
		        {
		            $query->where('posts.id', '=', $seller_product_2);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			}

			$data['sellerPosts'] = DB::table('posts')->where(function ($query) use ($seller_id)
	        {
	            $query->where('posts.user_id', '=', $seller_id);

	        })
			->join('pictures', 'posts.id', '=', 'pictures.post_id')
			->where('pictures.position' , 1)
	        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->get();
	  		
			$data['buyerPosts'] = DB::table('posts')->where(function ($query) use ($buyer_id)
	        {
	            $query->where('posts.user_id', '=', $buyer_id);

	        })
			->join('pictures', 'posts.id', '=', 'pictures.post_id')
	        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->get();
			
			return $data;
		}
	}

	public function edit($postId , $offerId, Request $request)
	{
	    
        $getMakeofferCount = \DB::table('makeanoffers')
            ->where('id','=',$offerId)
            ->first();
            
            // if($getMakeofferCount->is_read == '0')
            // {
            //   if($getMakeofferCount->offer_maker_id != $request->user_id)
            //   {
            //       $response_d =  \DB::table('makeanoffers')
            //           ->where('id', $offerId)
            //           ->update(['is_read' => '1']);
            //   }
            // }
            
            
        if(!empty($getMakeofferCount))
        {
           if($getMakeofferCount->is_read == '0')
           {
               if($request->user_id != $getMakeofferCount->offer_maker_id || $getMakeofferCount->approve_seller == 1 || $getMakeofferCount->approve_seller == 2)
               {
                   if($getMakeofferCount->approve_seller == 1)
                   {
                        if($getMakeofferCount->counter_offer == '0')      
                        {
                            if($request->user_id == $getMakeofferCount->buyer_id)
                            {
                                    $response_d =  \DB::table('makeanoffers')
                                      ->where('id', $offerId)
                                      ->update(['is_read' => '1']);
                            }   
                            else
                            {
                                
                            }
                        }
                        else
                        {
                            if($request->user_id == $getMakeofferCount->offer_maker_id)
                            {
                                $response_d =  \DB::table('makeanoffers')
                                  ->where('id', $offerId)
                                  ->update(['is_read' => '1']);
                            }
                        }
                   }
                   else
                   {
                       if($getMakeofferCount->approve_seller == 2)
                       {
                            if($request->user_id != $getMakeofferCount->offer_maker_id)
                            {
                                
                            }
                            else
                            {
                                $response_d =  \DB::table('makeanoffers')
                                  ->where('id', $offerId)
                                  ->update(['is_read' => '1']);
                            }
                       }
                       else
                       {
                           $response_d =  \DB::table('makeanoffers')
                                  ->where('id', $offerId)
                                  ->update(['is_read' => '1']);
                       }
                   }
                }
           }
        }
            
            
            
            
            
            
            
            
            
            
            
            
			$data = [];
			// $data['makeanoffer'] = Makeanoffer::where(['post_id' => $id , 'status' => 1])->first();
			$data['makeanoffer'] = Makeanoffer::findOrFail($offerId);
			$data['post'] = Post::findOrFail($postId);
			$data['picture'] = Picture::where(['post_id' => $data['post']['id'] , 'position' => 1])->first();
			$data['buyer'] = User::where(['id' => $data['makeanoffer']['buyer_id']])->first();
			$data['seller'] = User::where(['id' => $data['makeanoffer']['seller_id']])->first();
			$seller_id = $data['seller']['id'];
			$buyer_id = $data['buyer']['id'];
			$buyer_product_1 = $data['makeanoffer']['buyer_product_1'];
			$buyer_product_2 = $data['makeanoffer']['buyer_product_2'];
			$buyer_product_3 = $data['makeanoffer']['buyer_product_3'];
			$seller_product_1 = $data['makeanoffer']['seller_product_1'];
			$seller_product_2 = $data['makeanoffer']['seller_product_2'];

			if(!empty($buyer_product_1))
			{
				$data['buyerProduct1'] = DB::table('posts')->where(function ($query) use ($buyer_product_1)
		        {
		            $query->where('posts.id', '=', $buyer_product_1);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			} else {
			    $data['buyerProduct1'] = (object) array();
			}

			if(!empty($buyer_product_2))
			{
				$data['buyerProduct2'] = DB::table('posts')->where(function ($query) use ($buyer_product_2)
		        {
		            $query->where('posts.id', '=', $buyer_product_2);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			} else {
			    $data['buyerProduct2'] = (object) array();
			}

			if(!empty($buyer_product_3))
			{
				$data['buyerProduct3'] = DB::table('posts')->where(function ($query) use ($buyer_product_3)
		        {
		            $query->where('posts.id', '=', $buyer_product_3);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			} else {
			    $data['buyerProduct3'] = (object) array();
			}

			if(!empty($seller_product_1))
			{
			   	$data['sellerProduct1'] = DB::table('posts')->where(function ($query) use ($seller_product_1)
		        {
		            $query->where('posts.id', '=', $seller_product_1);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			} else {
			    $data['sellerProduct1'] = (object) array();
			}

			if(!empty($seller_product_2))
			{
				$data['sellerProduct2'] = DB::table('posts')->where(function ($query) use ($seller_product_2)
		        {
		            $query->where('posts.id', '=', $seller_product_2);

		        })
				->join('pictures', 'posts.id', '=', 'pictures.post_id')
		        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->first();
			} else {
			   $data['sellerProduct2'] = (object) array();
			}

			$data['sellerPosts'] = DB::table('posts')->where(function ($query) use ($seller_id)
	        {
	            $query->where('posts.user_id', '=', $seller_id);
                $query->where('posts.reviewed', '=', 1);
	            $query->where('posts.archived', '=', 0);

	        })
			->join('pictures', 'posts.id', '=', 'pictures.post_id')
			->where('pictures.position' , 1)
	        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->get();
	  		
			$data['buyerPosts'] = DB::table('posts')->where(function ($query) use ($buyer_id)
	        {
	            $query->where('posts.user_id', '=', $buyer_id);
	            $query->where('posts.reviewed', '=', 1);
	            $query->where('posts.archived', '=', 0);

	        })
			->join('pictures', 'posts.id', '=', 'pictures.post_id')
	        ->select('posts.id','posts.title','posts.price','pictures.filename','pictures.position','pictures.active')->get();
			
			
			return response()->json(['results'=>$data]);
			//return view('account.makeanoffers-edit', $data);
		// $data = [];
		// $data['makeanoffers'] = Makeanoffer::findOrFail($id);
		// $data['post'] = Post::findOrFail($data['makeanoffers']['post_id']);
		// $seller_id = $data['makeanoffers']['seller_id'];
  //       $buyer_id = $data['makeanoffers']['buyer_id'];
		
		// $data['sellerPosts'] = DB::table('posts')->where(function ($query) use ($seller_id)
  //       {
  //           $query->where('posts.user_id', '=', $seller_id);

  //       })
		// ->join('pictures', 'posts.id', '=', 'pictures.post_id')
  //       ->select('pictures.filename','pictures.position','pictures.active')->get();
		// $data['buyerPosts'] = DB::table('posts')->where(function ($query) use ($buyer_id)
  //       {
  //           $query->where('posts.user_id', '=', $buyer_id);

  //       })
		// ->join('pictures', 'posts.id', '=', 'pictures.post_id')
  //       ->select('pictures.filename','pictures.position','pictures.active')->get();
		
		// $data['pictures'] = DB::table('pictures')->select('pictures.filename','pictures.position','pictures.active')->where(['post_id' => $data['makeanoffers']['post_id'] , 'position' => 1])->first();

		// $all_post = DB::table('posts')->where(function ($query) use ($seller_id , $buyer_id)
  //       {
  //           if(auth()->user()->user_type_id == 2)
  //           {
  //           	$query->where('posts.user_id', '=', $seller_id);
  //           }
  //           elseif(auth()->user()->user_type_id == 3)
  //           {
  //           	$query->where('posts.user_id', '=', $buyer_id);
  //           }	 
  //       })
 	// 	->orderByDesc('posts.id')->get();

		// $data['all_post'] = $all_post;
		// return view('account.makeanoffers-edit', $data);
	}

	public function store( Request $request)
	{
		
		$postId = $request->input('post_id');
		$offerId = $request->input('makeanoffer_id');
		// $offerPriceSeller = $request->input('offer_price_seller');
		// $offerPriceBuyer = $request->input('offer_price_buyer');
		// $status = $request->input('status');

		$post = Post::unarchived()->findOrFail($postId);
		
		$user = User::findOrFail($request->input('user_id'));
		// $makeanoffer = Makeanoffer::findOrFail($offerId);

        $makeanoffer = new Makeanoffer();

        $makeanoffer->post_id = $post->id;
        if(!empty($offerId))
        {
        	$makeanoffer->offer_parent = $offerId;
        }
        if (!empty($request->input('buyer_product_1')) && $request->input('buyer_product_1') !== $request->input('buyer_product_2') && $request->input('buyer_product_1') !== $request->input('buyer_product_3')) {
        	$makeanoffer->buyer_product_1 = $request->input('buyer_product_1');
        }
        if (!empty($request->input('buyer_product_2')) && $request->input('buyer_product_2') !== $request->input('buyer_product_1') && $request->input('buyer_product_2') !== $request->input('buyer_product_3')) {
        	$makeanoffer->buyer_product_2 = $request->input('buyer_product_2');
        }
        if (!empty($request->input('buyer_product_3')) && $request->input('buyer_product_3') !== $request->input('buyer_product_1') && $request->input('buyer_product_3') !== $request->input('buyer_product_1')) {
        	$makeanoffer->buyer_product_3 = $request->input('buyer_product_3');
        }

        if (!empty($request->input('seller_product_1')) && $request->input('seller_product_1') !== $request->input('seller_product_2')) {
        	$makeanoffer->seller_product_1 = $request->input('seller_product_1');
        }

        if (!empty($request->input('seller_product_2')) && $request->input('seller_product_2') !== $request->input('seller_product_1')) {
        	$makeanoffer->seller_product_2 = $request->input('seller_product_2');
        }
        
        if(!empty($request->input('offer_price_seller')))
        {
        	$makeanoffer->original_price = $request->input('offer_price_seller');
        }
        else
        {
        	$makeanoffer->original_price = $post->price;	
        }
        
        if(!empty($request->input('offer_price_buyer')))
        {
        	$makeanoffer->offer_price = $request->input('offer_price_buyer');
        }
        else{
        	$makeanoffer->offer_price = $request->input('offer_price_buyer');	
        }
        
        $makeanoffer->description_text = 'Start negotiation with buyer';
        // if (auth()->user()->user_type_id == 2) {
        $makeanoffer->buyer_id = $request->input('user_id');
        // } else {
        //     $makeanoffer->buyer_id = $request->user_id;
        // }
        $makeanoffer->seller_id = $post->user_id;
        if ($user->user_type_id == 1) {
            $makeanoffer->is_read_admin = 1;
        } else {
            $makeanoffer->is_read_admin = 0;
        }
        if ($user->user_type_id == 2) {
            $makeanoffer->is_read_professional = 1;
        } else {
            $makeanoffer->is_read_professional = 0;
        }
        if ($user->user_type_id == 3) {
            $makeanoffer->is_read_individual = 1;
        } else {
            $makeanoffer->is_read_individual = 1;
        }
        $makeanoffer->approve_seller = 0;
        $makeanoffer->approve_buyer = 0;
        $makeanoffer->approve_admin = 0;
        $makeanoffer->status = 1;
        $makeanoffer->offer_maker_id = $request->input('user_id');
        $makeanoffer->save();

        
        
         
        $sellername = $post->contact_name;
        $selleremail = $post->email;
        $buyername = $user->user_name;
        $from_email = $user->email;
        
        $data['url'] = lurl('/').'/'.slugify($post->title).'/'.$post->id;
        $data['sellername'] = $sellername;
        $data['buyername'] = $buyername;
        
        try {
            \Mail::send('emails.post.offer_send', $data, function($message) use ($buyername, $from_email,$selleremail)
            {
                $message->to($selleremail);
                $message->subject('New Offer');
                $message->replyTo($from_email, $buyername);        
            });    
            $msg = t("Your message has sent successfully to :contact_name.", ['contact_name' => $post->contact_name]);
            flash($msg)->success();
        } catch (\Exception $e) {
            flash($e->getMessage())->error();
        }

        // try {
        //     $post->notify(new SellerContacted($post, $message));

        //     $msg = t("Your message has sent successfully to :contact_name.", ['contact_name' => $post->contact_name]);
        //     flash($msg)->success();
        // } catch (\Exception $e) {
        //     flash($e->getMessage())->error();
        // }



        // return redirect(config('app.locale') . '/' . $post->uri);

		// echo "<pre>";
		// dd($request);
		// exit;

		// $makeanoffer = Makeanoffer::find($offerId);
		// $makeanoffer->description_text = $offerDescription;
		// $makeanoffer->offer_price = $offerPrice;
		// $makeanoffer->approve_seller = $status;
		// $makeanoffer->is_read_professional = 1;
		// $makeanoffer->update();

		//return redirect('account/makeanoffers/'.$postId.'/edit/'.$makeanoffer->id);
		return response()->json(['results'=>'Success','postId'=>$postId,'makeanofferid'=>$makeanoffer->id]);
	}
	public function storeeditoffer( Request $request)
	{
	    
		
		// exit;
		$postId = $request->input('post-id');
		$offerId = $request->input('makeanoffer-id');
		// $offerPriceSeller = $request->input('offer_price_seller');
		// $offerPriceBuyer = $request->input('offer_price_buyer');
		// $status = $request->input('status');

		$post            = Post::unarchived()->findOrFail($postId);
		$makeanofferdata = Makeanoffer::findOrFail($offerId);
		// echo "<pre>";
		// print_r($makeanofferdata->id);
		// exit;
		

		
		
		
		
		
		
		
		
		
        $makeanoffer = new Makeanoffer();

        $makeanoffer->post_id = $post->id;
        if(!empty($offerId))
        {
        	$makeanoffer->offer_parent = $offerId;
        }
        else
        {
        	$makeanoffer->offer_parent = $makeanofferdata->id;
        }
        // if (!empty($request->input('buyer_product_1')) && $request->input('buyer_product_1') !== $request->input('buyer_product_2') && $request->input('buyer_product_1') !== $request->input('buyer_product_3')) {
        // 	$makeanoffer->buyer_product_1 = $request->input('buyer_product_1');
        // }
        // else
        // {
        	$makeanoffer->buyer_product_1 = !empty($request->input('buyer_product_1'))?$request->input('buyer_product_1'):0;
        // }
        // if (!empty($request->input('buyer_product_2')) && $request->input('buyer_product_2') !== $request->input('buyer_product_1') && $request->input('buyer_product_2') !== $request->input('buyer_product_3')) {
        // 	$makeanoffer->buyer_product_2 = $request->input('buyer_product_2');
        // }
        // else
        // {
        	$makeanoffer->buyer_product_2 = !empty($request->input('buyer_product_2'))?$request->input('buyer_product_2'):0;
        // }
        // if (!empty($request->input('buyer_product_3')) && $request->input('buyer_product_3') !== $request->input('buyer_product_1') && $request->input('buyer_product_3') !== $request->input('buyer_product_2')) {
        // 	$makeanoffer->buyer_product_3 = $request->input('buyer_product_3');
        // }
        // else
        // {
        	$makeanoffer->buyer_product_3 = !empty($request->input('buyer_product_3'))?$request->input('buyer_product_3'):0;
        // }

        // if (!empty($request->input('seller_product_1')) && $request->input('seller_product_1') !== $request->input('seller_product_2')) {
        // 	$makeanoffer->seller_product_1 = $request->input('seller_product_1');
        // }
        // else
        // {
        	$makeanoffer->seller_product_1 = !empty($request->input('seller_product_1'))?$request->input('seller_product_1'):0;
        // }

        // if (!empty($request->input('seller_product_2')) && $request->input('seller_product_2') !== $request->input('seller_product_1')) {
        // 	$makeanoffer->seller_product_2 = $request->input('seller_product_2');
        // }
        // else
        // {
        	$makeanoffer->seller_product_2 = !empty($request->input('seller_product_2'))?$request->input('seller_product_2'):0;
        // }
        if(!empty($request->input('offer_price_seller')))
        {
        	$makeanoffer->original_price = $request->input('offer_price_seller');
        }
        else
        {
        	$makeanoffer->original_price = $makeanofferdata->original_price;
        }
        // $makeanoffer->original_price = $post->price;
        if(!empty($request->input('offer_price_buyer')))
        {
        	$makeanoffer->offer_price = $request->input('offer_price_buyer');
        }
        else{
        	$makeanoffer->offer_price = $makeanofferdata->offer_price;	
        }
        
        $makeanoffer->description_text = 'Start negotiation with buyer';
        
        $makeanoffer->buyer_id = $makeanofferdata->buyer_id;
        $makeanoffer->seller_id = $post->user_id;
        
        if (auth()->user()->user_type_id == 1) {
            $makeanoffer->is_read_admin = 1;
        } else {
            $makeanoffer->is_read_admin = 0;
        }
        if (auth()->user()->user_type_id == 2) {
            $makeanoffer->is_read_professional = 1;
        } else {
            $makeanoffer->is_read_professional = 0;
        }
        if (auth()->user()->user_type_id == 3) {
            $makeanoffer->is_read_individual = 1;
        } else {
            $makeanoffer->is_read_individual = 1;
        }
        $makeanoffer->approve_seller = 0;
        $makeanoffer->approve_buyer = 0;
        $makeanoffer->approve_admin = 0;
        $makeanoffer->status = 1;
        $makeanoffer->offer_maker_id = $request->user_id;
        $makeanoffer->save();

        // try {
        //     $post->notify(new SellerContacted($post, $message));

        //     $msg = t("Your message has sent successfully to :contact_name.", ['contact_name' => $post->contact_name]);
        //     flash($msg)->success();
        // } catch (\Exception $e) {
        //     flash($e->getMessage())->error();
        // }


		$offer_maker_name = User::where(['id' => $makeanofferdata->offer_maker_id])->first();
		
        $sellername = $offer_maker_name->username;
        $selleremail = $offer_maker_name->email;
        $buyername = auth()->user()->username;
        $from_email = auth()->user()->email;
        
        $data['url'] = lurl('/').'/'.slugify($post->title).'/'.$post->id;
        $data['sellername'] = $sellername;
        $data['buyername'] = $buyername;
        
        try {
            \Mail::send('emails.post.offer_send', $data, function($message) use ($buyername, $from_email,$selleremail)
            {
                $message->to($selleremail);
                $message->subject('New Offer');
                $message->replyTo($from_email, $buyername);        
            });    
        } catch (\Exception $e) {
            flash($e->getMessage())->error();
        }




        // return redirect(config('app.locale') . '/' . $post->uri);

		// echo "<pre>";
		// dd($request);
		// exit;

		// $makeanoffer = Makeanoffer::find($offerId);
		// $makeanoffer->description_text = $offerDescription;
		// $makeanoffer->offer_price = $offerPrice;
		// $makeanoffer->approve_seller = $status;
		// $makeanoffer->is_read_professional = 1;
		// $makeanoffer->update();

		return redirect('account/makeanoffers/'.$postId.'/edit/'.$makeanoffer->id);
	}

	public function dealseller($postId , $offerId, Request $request)
	{
	    
        $makeanofferget = Makeanoffer::find($offerId);
		 //$count = $makeanofferget->count();
		
    	$offer_maker_id = $makeanofferget->offer_maker_id;
    	
    	$offer_maker_name = User::where(['id' => $offer_maker_id])->first();

    	$to_name  = $offer_maker_name->username;
    	$to_email = $offer_maker_name->email;
    	
        $from_name = $request->username;
        $from_email = $request->email;
        
        $data['toname'] = $to_name;
        $data['fromname'] = $from_name;
		$post = Post::unarchived()->findOrFail($postId);
        $data['url'] = lurl('/').'/'.slugify($post->title).'/'.$post->id;
        
	    \Mail::send('emails.post.offer_accept', $data, function($message) use ($to_email,$from_name,$from_email)
        {
            $message->to($to_email);
            $message->subject('Offer Acepted');
            $message->replyTo($from_email, $from_name);        
        });    
	    
	    
	   	$makeanoffer = Makeanoffer::find($offerId);
		$makeanoffer->approve_seller = 1;
		$makeanoffer->is_read = 0;
		$makeanoffer->update();
		//return redirect('account/makeanoffers/'.$postId.'/edit/'.$offerId);
		return response()->json(['results'=>'Success','makeanofferid'=>$offerId,'postId'=>$postId]);
		
	}
	public function notdealseller($postId , $offerId, Request $request)
	{
	    $makeanofferget = Makeanoffer::find($offerId);
    	$offer_maker_id = $makeanofferget->offer_maker_id;
    	
    	$offer_maker_name = User::where(['id' => $offer_maker_id])->first();

    	$to_name  = $offer_maker_name->username;
    	$to_email = $offer_maker_name->email;
    	
        $from_name = $request->username;
        $from_email = $request->email;
        
        $post = Post::unarchived()->findOrFail($postId);
        $data['url'] = lurl('/').'/'.slugify($post->title).'/'.$post->id;
        
        $data['toname'] = $to_name;
        $data['fromname'] = $from_name;
        
        
        
	    \Mail::send('emails.post.offer_reject', $data, function($message) use ($to_email,$from_name,$from_email)
        {
            $message->to($to_email);
            $message->subject('Offer Rejected');
            $message->replyTo($from_email, $from_name);        
        });    
	    
	    
	    
		$makeanoffer = Makeanoffer::find($offerId);
		$makeanoffer->approve_seller = 2;
		$makeanoffer->is_read = 0;
		$makeanoffer->update();
		//return redirect('account/makeanoffers/'.$postId.'/edit/'.$offerId);
		return response()->json(['results'=>'Success','makeanofferid'=>$offerId,'postId'=>$postId]);
	}

	public function dealbuyer($id)
	{
		$makeanoffer = Makeanoffer::find($id);
		$makeanoffer->approve_seller = 1;
		$makeanoffer->is_read = 0;
		$makeanoffer->update();
		//return redirect('account/makeanoffers/'.$id.'/edit');
		return response()->json(['results'=>'Success','makeanofferid'=>$id]);
	}
	public function notdealbuyer($id)
	{
		$makeanoffer = Makeanoffer::find($id);
		$makeanoffer->approve_seller = 0;
		$makeanoffer->is_read = 0;
		$makeanoffer->update();
		//return redirect('account/makeanoffers/'.$id.'/edit');
		return response()->json(['results'=>'Success','makeanofferid'=>$id]);
	}

	public function addmore($id, MakeAnOfferEditRequest $request )
	{
		$makeanoffer = Makeanoffer::find($id);
		$makeanoffer->next_post_id = $request->input('post');
		$makeanoffer->approve_seller = 0;
		$makeanoffer->update();
		return redirect('account/makeanoffers/'.$id.'/edit');
	}

	public function updatemakeanoffer ($id, MakeAnOfferRequest $request)
	{
		$makeanoffer = Makeanoffer::find($id);
		$makeanoffer->offer_price = $request->input('offer_price');
		$makeanoffer->approve_seller = 0;
		$makeanoffer->update();
		return redirect('account/makeanoffers/'.$id.'/edit');
	}

	public function destroy($id)
	{
		$makeanoffer = Makeanoffer::destroy($id);
		//return redirect('account/makeanoffers/');
		return response()->json(['results'=>'Deleted']);
	}
	
	
	public function closeoffer($id)
	{
	    $makeanoffer = Makeanoffer::find($id);
	    $makeanoffer->close_offer = 1;
	    $makeanoffer->is_read = 0;
	    $makeanoffer->save();
	    return redirect()->back()->with('success','Offer successfully closed!');
	}
	
	public function counteroffer($id)
	{
        $makeanoffer = Makeanoffer::find($id);
	    $makeanoffer->buyer_product_1 = 0;
        $makeanoffer->buyer_product_2 = 0;
        $makeanoffer->buyer_product_3 = 0;
        $makeanoffer->seller_product_1 = 0;
        $makeanoffer->seller_product_2 = 0;
        $makeanoffer->counter_offer = 1;
        $makeanoffer->is_read = 0;
	    $makeanoffer->save();
	    return redirect()->back()->with('success','Counter offer successfully set!');
	    
	}
	
	//App api implementation
	
    public function makeanoffersapp(Request $request) {
        
       
        $sellerId = $request->input('receiver_id');
        $postId = $request->input('post_id');

        $post = Post::unarchived()->findOrFail($postId);
		
		$user = User::findOrFail($request->input('user_id'));

        $makeanoffer = new Makeanoffer();

        $makeanoffer->post_id = $post->id;
        
        if (!empty($request->input('buyer_product_1')) && $request->input('buyer_product_1') !== $request->input('buyer_product_2') && $request->input('buyer_product_1') !== $request->input('buyer_product_3')) {
        	$makeanoffer->buyer_product_1 = $request->input('buyer_product_1');
        }
        if (!empty($request->input('buyer_product_2')) && $request->input('buyer_product_2') !== $request->input('buyer_product_1') && $request->input('buyer_product_2') !== $request->input('buyer_product_3')) {
        	$makeanoffer->buyer_product_2 = $request->input('buyer_product_2');
        }
        if (!empty($request->input('buyer_product_3')) && $request->input('buyer_product_3') !== $request->input('buyer_product_1') && $request->input('buyer_product_3') !== $request->input('buyer_product_1')) {
        	$makeanoffer->buyer_product_3 = $request->input('buyer_product_3');
        }

        if (!empty($request->input('seller_product_1')) && $request->input('seller_product_1') !== $request->input('seller_product_2')) {
        	$makeanoffer->seller_product_1 = $request->input('seller_product_1');
        }

        if (!empty($request->input('seller_product_2')) && $request->input('seller_product_2') !== $request->input('seller_product_1')) {
        	$makeanoffer->seller_product_2 = $request->input('seller_product_2');
        }
        
        if(!empty($request->input('offer_price_seller')))
        {
        	$makeanoffer->original_price = $request->input('offer_price_seller');
        }
        else
        {
        	$makeanoffer->original_price = $post->price;	
        }
        
        if(!empty($request->input('offer_price_buyer')))
        {
        	$makeanoffer->offer_price = $request->input('offer_price_buyer');
        }
        else{
        	$makeanoffer->offer_price = 0;	
        }
        
        $makeanoffer->description_text = $request->input('description_text');
        
        $makeanoffer->buyer_id = $request->input('user_id');
        
        $makeanoffer->seller_id = $sellerId;
        if ($user->user_type_id == 1) {
            $makeanoffer->is_read_admin = 1;
        } else {
            $makeanoffer->is_read_admin = 0;
        }
        if ($user->user_type_id == 2) {
            $makeanoffer->is_read_professional = 1;
        } else {
            $makeanoffer->is_read_professional = 0;
        }
        if ($user->user_type_id == 3) {
            $makeanoffer->is_read_individual = 1;
        } else {
            $makeanoffer->is_read_individual = 1;
        }
        $makeanoffer->approve_seller = 0;
        $makeanoffer->approve_buyer = 0;
        $makeanoffer->approve_admin = 0;
        $makeanoffer->status = 1;
        $makeanoffer->offer_maker_id = $request->input('user_id');
        $makeanoffer->save();
     
        $fcmId = $user->fcm_id;
        error_reporting(-1);
        ini_set('display_errors', 'On');
        $firebase = new Firebase();
        $push = new Push();
        $payload = array(); 
        $data = array();
        
        
        $data['url'] = lurl('/').'/'.slugify($post->title).'/'.$post->id;
        $data['postId'] = $post->id;
        $data['offerId'] = $makeanoffer->id;
        array_push($payload, $data);                
        // notification title
        $title = $post->contact_name.' has send you an offer';             
        // notification message
        $message = "Makeanoffer Data"; 
        $type = "makeanoffer";                      
        // push type - single user / topic
        $push_type = "individual";     
        $push->setTitle($title);
        $push->setType($type);
        $push->setMessage($message);
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);
        $json = '';
        $firebaseresponse = '';
        if ($push_type == 'topic') 
        {
            $json = $push->getPush();
            $firebaseresponse = $firebase->sendToTopic('global', $json);
        }
        else if ($push_type == 'individual') 
        {
          $json = $push->getPush();
          $firebaseresponse = $firebase->send($fcmId, $json);
          //echo $firebaseresponse;
        }
		
		return response()->json(['results'=>'Success','postId'=>$postId,'makeanofferid'=>$makeanoffer->id, 'firebaseresponse'=>$firebaseresponse]);
    }
    
    
    public function dealsellerapp($postId , $offerId, Request $request)
	{
	    
        $makeanofferget = Makeanoffer::find($offerId);
		
    	$offer_maker_id = $makeanofferget->offer_maker_id;
    	
    	$offer_maker_name = User::where(['id' => $offer_maker_id])->first();

    	$to_name  = $offer_maker_name->username;

        $from_name = $request->username;
        
        $post = Post::unarchived()->findOrFail($postId);
        
        $data['url'] = lurl('/').'/'.slugify($post->title).'/'.$post->id;
        
        $data['toname'] = $to_name;
        $data['fromname'] = $from_name;
        
        $fcmId = $offer_maker_name->fcm_id;
        error_reporting(-1);
        ini_set('display_errors', 'On');
        $firebase = new Firebase();
        $push = new Push();
        $payload = array();  
      
        array_push($payload, $data);                
        // notification title
        $title = 'Offer accepted';             
        // notification message
        $message = "Offer accepted Data"; 
        $type = "Offeraccepted";                      
        // push type - single user / topic
        $push_type = "individual";     
        $push->setTitle($title);
        $push->setType($type);
        $push->setMessage($message);
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);
        $json = '';
        $firebaseresponse = '';
        if ($push_type == 'topic') 
        {
            $json = $push->getPush();
            $firebaseresponse = $firebase->sendToTopic('global', $json);
        }
        else if ($push_type == 'individual') 
        {
          $json = $push->getPush();
          $firebaseresponse = $firebase->send($fcmId, $json);
          //echo $firebaseresponse;
        }
        
	    
	   	$makeanoffer = Makeanoffer::find($offerId);
		$makeanoffer->approve_seller = 1;
		$makeanoffer->is_read = 0;
		$makeanoffer->update();
		//return redirect('account/makeanoffers/'.$postId.'/edit/'.$offerId);
		return response()->json(['results'=>'Success','makeanofferid'=>$offerId,'postId'=>$postId, 'firebaseresponse' => $firebaseresponse]);
		
	}
	
	
	public function notdealsellerapp($postId , $offerId, Request $request)
	{
	    $makeanofferget = Makeanoffer::find($offerId);
    	$offer_maker_id = $makeanofferget->offer_maker_id;
    	
    	$offer_maker_name = User::where(['id' => $offer_maker_id])->first();

    	$to_name  = $offer_maker_name->username;
    	
        $from_name = $request->username;

        $post = Post::unarchived()->findOrFail($postId);
        $data['url'] = lurl('/').'/'.slugify($post->title).'/'.$post->id;
        
        $data['toname'] = $to_name;
        $data['fromname'] = $from_name;
        
	    $fcmId = $offer_maker_name->fcm_id;
        error_reporting(-1);
        ini_set('display_errors', 'On');
        $firebase = new Firebase();
        $push = new Push();
        $payload = array();  
      
        array_push($payload, $data);                
        // notification title
        $title = 'Offer Rejected';             
        // notification message
        $message = "Offer Rejected Data"; 
        $type = "offerejected";                      
        // push type - single user / topic
        $push_type = "individual";     
        $push->setTitle($title);
        $push->setType($type);
        $push->setMessage($message);
        $push->setIsBackground(FALSE);
        $push->setPayload($payload);
        $json = '';
        $firebaseresponse = '';
        if ($push_type == 'topic') 
        {
            $json = $push->getPush();
            $firebaseresponse = $firebase->sendToTopic('global', $json);
        }
        else if ($push_type == 'individual') 
        {
          $json = $push->getPush();
          $firebaseresponse = $firebase->send($fcmId, $json);
          //echo $firebaseresponse;
        }
        
	    
	    
		$makeanoffer = Makeanoffer::find($offerId);
		$makeanoffer->approve_seller = 2;
		$makeanoffer->is_read = 0;
		$makeanoffer->update();
		return response()->json(['results'=>'Success','makeanofferid'=>$offerId,'postId'=>$postId, 'firebaseresponse' => $firebaseresponse]);
	}

}