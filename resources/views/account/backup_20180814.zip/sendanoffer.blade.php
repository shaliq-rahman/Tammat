{{--
 * LaraClassified - Geo Classified Ads CMS
 * Copyright (c) BedigitCom. All Rights Reserved
 *
 * Website: http://www.bedigit.com
 *
 * LICENSE
 * -------
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the inclusion
 * of the above copyright notice. If you Purchased from Codecanyon,
 * Please read the full License from here - http://codecanyon.net/licenses/standard
--}}
<?php
if (auth()->check()) {
	$addmore = '#addmore';
}
else
{
	$contactMakeAnOffer = '#quickLogin';	
}

if (auth()->check()) {
	$updateoffer = '#updateoffer';
}
else
{
	$contactMakeAnOffer = '#quickLogin';	
}
?>
@extends('layouts.master')
@include('common.spacer')
@section('content')
	<div class="main-container">
		<div class="container">
			<div class="row">
				<div class="col-md-12 page-content">
					<div class="inner-box category-content">
						<h2 class="title-2">
							<strong> <i class="icon-docs"></i> {{ t('Update Offer') }}</strong> -&nbsp;
							<?php $attr = ['slug' => slugify($post->title), 'id' => $post->id]; ?>
							<a href="{{ lurl($post->uri, $attr) }}" class="tooltipHere" title="" data-placement="top"
								data-toggle="tooltip"
								data-original-title="{!! $post->title !!}">
								{!! str_limit($post->title, 45) !!}
							</a>
						</h2>
						<form class="form-horizontal" id="postForm" method="POST" action="{{ url('account/makeanoffers/store')}}" enctype="multipart/form-data">
							<input type="hidden" name="post-id" value="{{ $post->id }}" />
								<?php

									if (!empty($picture->filename)) {
                                        $postImg = resize($picture->filename, 'medium');
                                    } else {
                                        $postImg = resize(config('larapen.core.picture.default'));
                                    }
								?>
									
								<div class="row brefcase-row">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="col-md-5 col-lg-5 col-sm-5">
											<h1 style="text-align: center; color: #3c80af;">{{ $buyer->username }}</h1>	
											<div class="col-md-12 col-lg-12 col-sm-12 buyer-face">
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12 brefcase-grip">
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12 brefcase">
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div id="container5" class="col-md-6 col-lg-6 col-sm-6 picture-container-up">
									        			<input class="buyer-product-selected" type="hidden" name="buyer_product_3" value="" />
									        			<div class="col-md-12 col-lg-12 col-sm-12 hide">
												            <a class="thumbnail" href="#"><img alt="" src="{{$postImg}}"></a>
												            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
												            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $post->title !!}">{!! $post->title !!}</span><br> <span>
												            		@if ($post->price > 0)
																	{!! \App\Helpers\Number::money($post->price) !!}
																	@else
																	<!--{!! \App\Helpers\Number::money(' --') !!}-->
																		{{t('Free')}}
																	@endif
																</span>
																</p> 
												        	</div>
												        </div>
									        		</div>
									        		<div class="col-md-6 col-lg-6 col-sm-6 picture-container-up-last">
									        			<div class="col-md-12 col-lg-12 col-sm-12">
										        			<div class="col-md-12 col-lg-12 col-sm-12 cash-heading">
												        		{{-- <label>Cash</label> --}}
												        	</div>
											        	</div>
											        	<div class="col-md-12 col-lg-12 col-sm-12">
												        	<div class="input-group offer-price">
												        		@if(auth()->user()->user_type_id == 2)
																<input id="offer_price_buyer" name="offer_price_buyer" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{ $post->price }}" disabled>
																@else
																<input id="offer_price_buyer" name="offer_price_buyer" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{ $post->price }}">
																@endif
																<span class="input-group-addon">
        															{!! substr(\App\Helpers\Number::money(''), 0 , -1) !!}
    															</span>
															</div>
														</div>
									        		</div>	
									        	</div>
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div id="container1" class="col-md-6 col-lg-6 col-sm-6 picture-container-down">
									        			<input class="buyer-product-selected" type="hidden" name="buyer_product_1" value="" />
									        		</div>
									        		<div id="container2" class="col-md-6 col-lg-6 col-sm-6 picture-container-down-last">
									        			<input class="buyer-product-selected" type="hidden" name="buyer_product_2" value="" />
									        		</div>	
									        	</div>	
											</div>	
											{{-- <div class="container">
											  <div class='row'> --}}
											    <div class="col-md-12 product-carousel">
											      <div class="carousel slide media-carousel" id="media1">
											        <div class="carousel-inner buyer-carousel">
											        <?php  $j = 0 ;?>
											        @foreach($buyerPosts->unique('id') as $buyerPost)
											        <?php

														if (!empty($picture->filename)) {
					                                        $postproductImg = resize($buyerPost->filename, 'medium');
					                                    } else {
					                                        $postproductImg = resize(config('larapen.core.picture.default'));
					                                    }
													?>
													
													<div id="drag<?=$j ?>" class="col-md-4 drag buyer-drag-product">
										                <a class="thumbnail" href="#"><img alt="" src="{{ $postproductImg }}"></a>
										                <input class="buyer-product" type="hidden" name="buyer_product" value="{{ $buyerPost->id }}" />
										                <div class="col-md-12 col-lg-12 col-sm-12 product-name">
										                	<p class="product-name-data">
										                		<span>
										                			{!! $buyerPost->title !!}
										                		</span>
										                		<br>
										                		<span>
											                		@if ($buyerPost->price > 0)
																	{!! \App\Helpers\Number::money($buyerPost->price) !!}
																	@else
																	<!--{!! \App\Helpers\Number::money(' --') !!}-->
																		{{t('Free')}}
																	@endif
										                		</span>
										                	</p> 
										                </div>	
										             </div>
											           
											        <?php  $j++;?>
											        @endforeach
											        </div>
											        @if($buyerPosts->unique('id')->count() > 3)
												        <a data-slide="prev" href="#media1" class="left carousel-control">‹</a>
												        <a data-slide="next" href="#media1" class="right carousel-control">›</a>
											        @endif
											      </div>                          
											    </div>
											    <div class="col-md-12 product-model-button hide">
											    	<div class="row">
											    		<div class="col-md-12 col-lg-12 col-sm-12">
											    			<button class="btn btn-primary col-md-12 col-lg-12 col-sm-12">Add Products</button>
											    		</div>	
											    	</div>	
											    </div>    
											  {{-- </div>
											</div> --}}
											<div class="col-md-12">
										    	<div class="row">
										    		<div class="col-md-3 col-lg-3 col-sm-3">
										    		</div>	
										    		<div class="col-md-6 col-lg-6 col-sm-6">
										    			<div class="form-group">
										    				<button type="submit" class="btn btn-success col-md-12 col-lg-12 col-sm-12">Send Offer</button>
										    			</div>
										    		</div>
										    		<div class="col-md-3 col-lg-3 col-sm-3">
										    		</div>	
										    	</div>	
										    </div>
										</div>	
										<div class="col-md-2 col-lg-2 col-sm-2 offer-arrow">
										</div>
										<div class="col-md-5 col-lg-5 col-sm-5">
											<h1 style="text-align: center; color: #3c80af;">{{$seller->username}}</h1>
											<div class="col-md-12 col-lg-12 col-sm-12 seller-face">
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12 brefcase-grip">
											</div>
											<div class="col-md-12 col-lg-12 col-sm-12 brefcase">
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div class="col-md-6 col-lg-6 col-sm-6 picture-container-up">
									        			<div class="col-md-12 col-lg-12 col-sm-12">
												            <a class="thumbnail" href="#"><img alt="" src="{{$postImg}}"></a>
												            <div class="col-md-12 col-lg-12 col-sm-12 product-name">
												            	<p class="product-name-data"><span class="tooltipHere" data-placement="top" data-toggle="tooltip" data-original-title="{!! $post->title !!}">{!! $post->title !!}</span><br> 
												            	<span>
												            		@if ($post->price > 0)
																	{!! \App\Helpers\Number::money($post->price) !!}
																	@else
																	<!--{!! \App\Helpers\Number::money(' --') !!}-->
																		{{t('Free')}}
																	@endif
												            	</span>
												            	</p>
												        	</div>
												        </div>
									        		</div>
									        		<div class="col-md-6 col-lg-6 col-sm-6 picture-container-up-last">
									        			<div class="col-md-12 col-lg-12 col-sm-12">
										        			<div class="col-md-12 col-lg-12 col-sm-12 cash-heading">
												        		{{-- <label>Cash</label> --}}
												        	</div>
											        	</div>
											        	<div class="col-md-12 col-lg-12 col-sm-12">
												        	<div class="input-group offer-price">
																@if(auth()->user()->user_type_id == 3)
																<input id="offer_price_seller" name="offer_price_seller" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{$post->price}}" disabled>
																@else
																<input id="offer_price_seller" name="offer_price_seller" type="text" placeholder="Offer Price" maxlength="60" class="form-control offer-price" value="{{$post->price}}">
																@endif
																<span class="input-group-addon">
        															{!! substr(\App\Helpers\Number::money(''), 0 , -1) !!}
    															</span>
															</div>
														</div>
									        		</div>	
									        	</div>
									        	<div class="col-md-12 col-lg-12 col-sm-12">
									        		<div id="container3" class="col-md-6 col-lg-6 col-sm-6 picture-container-down">
									        			<input class="seller-product-selected" type="hidden" name="seller_product_1" value="" />
									        		</div>
									        		<div id="container4" class="col-md-6 col-lg-6 col-sm-6 picture-container-down-last">
									        			<input class="seller-product-selected" type="hidden" name="seller_product_2" value="" />
									        		</div>	
									        	</div>	
											</div>
											{{-- <div class="container">
											  <div class='row'> --}}
											    <div class="col-md-12 product-carousel">
											      <div class="carousel slide media-carousel" id="media">
											        <div class="carousel-inner seller-carousel">
											        <?php  $j = 0 ;?>
											        @foreach($sellerPosts->unique('id') as $sellerPost)
											        <?php

														if (!empty($picture->filename)) {
					                                        $postproductImg = resize($sellerPost->filename, 'medium');
					                                    } else {
					                                        $postproductImg = resize(config('larapen.core.picture.default'));
					                                    }
													?>
													
													<div id="drag<?=$j ?>" class="col-md-4 drag seller-drag-product">
										                <a class="thumbnail" href="#"><img alt="" src="{{ $postproductImg }}"></a>
										                <input class="seller-product" type="hidden" name="seller_product" value="{{ $sellerPost->id }}" />
										                <div class="col-md-12 col-lg-12 col-sm-12 product-name">
										                	<p class="product-name-data">
										                		<span>
										                			{!! $sellerPost->title !!}
										                		</span>
										                		<br>
										                		<span>
											                		@if ($sellerPost->price > 0)
																	{!! \App\Helpers\Number::money($sellerPost->price) !!}
																	@else
																	<!--{!! \App\Helpers\Number::money(' --') !!}-->
																		{{t('Free')}}
																	@endif
										                		</span>
										                	</p> 
										                </div>	
										             </div>
											           
											        <?php  $j++;?>
											        @endforeach
											        
											        </div>
											        @if($sellerPosts->unique('id')->count() > 3)
												        <a data-slide="prev" href="#media" class="left carousel-control">‹</a>
												        <a data-slide="next" href="#media" class="right carousel-control">›</a>
												    @endif    
											      </div>                          
											    </div>
											    <div class="col-md-12 product-model-button hide">
											    	<div class="row">
											    		<div class="col-md-12 col-lg-12 col-sm-12">
											    			<button class="btn btn-primary col-md-12 col-lg-12 col-sm-12">Add Products</button>
											    		</div>	
											    	</div>	
											    </div>
											  {{-- </div>
											</div> --}}
											<div class="col-md-12 hide">
										    	<div class="row">
										    		<div class="col-md-6 col-lg-6 col-sm-6">
										    			<button class="btn btn-success col-md-12 col-lg-12 col-sm-12">Accept</button>
										    		</div>
										    		<div class="col-md-6 col-lg-6 col-sm-6">
										    			<button class="btn btn-danger col-md-12 col-lg-12 col-sm-12">Reject</button>
										    		</div>	
										    	</div>	
										    </div>
										</div>
									</div>
								</div>
								{{-- <div class="row desktop-button">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="col-md-4 col-lg-4 col-sm-4">
										</div>
										<div class="col-md-4 col-lg-4 col-sm-4 button-send-offer-div">
											<button class="btn btn-success col-md-10 col-lg-10 col-sm-10 button-send-offer ">Send Offer</button>
										</div>
										<div class="col-md-4 col-lg-4 col-sm-4">
										</div>
									</div>
								</div> --}}

								{{-- <div class="col-md-12 button-send-offer-div-mobile hide">
							    	<div class="row">
							    		<div class="col-md-12 col-lg-12 col-sm-12">
							    			<button class="btn btn-success col-md-12 col-lg-12 col-sm-12">Send Offer</button>
							    		</div>	
							    	</div>	
							    </div> --}}
						</form>	
					</div>
				</div>
			</div>
		</div>
	</div>	
@endsection

@section('after_styles')
	@include('layouts.inc.tools.wysiwyg.css')
@endsection

{{-- @section('add_more')
	@if (auth()->check() or config('settings.single.guests_can_contact_seller')=='1')
		@include('account.inc.add-more', array('all_post' => $all_post, 'makeanoffers' => $makeanoffers ))
	@endif
@endsection --}}

{{-- @section('update_offer')
	@if (auth()->check() or config('settings.single.guests_can_contact_seller')=='1')
		@include('account.inc.update-offer', array('all_post' => $all_post, 'makeanoffers' => $makeanoffers ))
	@endif
@endsection --}}
