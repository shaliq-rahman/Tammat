<!-- this (.mobile-filter-sidebar) part will be position fixed in mobile version -->
<?php
    $fullUrl = url(\Illuminate\Support\Facades\Request::getRequestUri());
    $tmpExplode = explode('?', $fullUrl);
    $fullUrlNoParams = current($tmpExplode);
?>
<div class="col-sm-3 page-sidebar mobile-filter-sidebar" style="padding-bottom: 20px;">
	<aside>
		<div class="inner-box enable-long-words">
			
			
            
            
            
            <!-- Date -->
            <div class="list-filter" style="display:none;">
                <h5 class="list-title"><strong><a href="#"> {{ t('Date Posted') }} </a></strong></h5>
                <div class="filter-date filter-content">
                    <ul>
                        @if (isset($dates) and !empty($dates))
                            @foreach($dates as $key => $value)
                                <li>
                                    <input type="radio" name="postedDate" value="{{ $key }}" id="postedDate_{{ $key }}" {{ (Request::get('postedDate')==$key) ? 'checked="checked"' : '' }}>
                                    <label for="postedDate_{{ $key }}">{{ $value }}</label>
                                </li>
                            @endforeach
                        @endif
                        <input type="hidden" id="postedQueryString" value="{{ httpBuildQuery(Request::except(['postedDate'])) }}">
                    </ul>
                </div>
            </div>
            
            
                @if (isset($cat))
                  <?php $style = 'style="display: none;"'; ?>
                @endif
               <!-- Category -->
			<div id="catsList" class="categories-list list-filter" <?php echo (isset($style)) ? $style : ''; ?>>
				<h5 class="list-title">
                    <strong><a href="#">{{ t('All Categories') }}</a></strong>
                </h5>
				<ul class="list-unstyled">
                    @if ($cats->groupBy('parent_id')->has(0))
					@foreach ($cats->groupBy('parent_id')->get(0) as $iCat)
						<li>
							<?php $attr = ['countryCode' => config('country.icode'), 'catSlug' => $iCat->slug]; ?>
							@if ((isset($uriPathCatSlug) and $uriPathCatSlug == $iCat->slug) or (Request::input('c') == $iCat->tid))
								<strong>
									<a href="{{ lurl(trans('routes.v-search-cat', $attr), $attr) }}" title="{{ $iCat->name }}">
										<span class="title">{{ $iCat->name }}</span>
										<span class="count">&nbsp;{{ $countCatPosts->get($iCat->tid)->total or 0 }}</span>
									</a>
								</strong>
							@else
								<a href="{{ lurl(trans('routes.v-search-cat', $attr), $attr) }}" title="{{ $iCat->name }}">
									<span class="title">{{ $iCat->name }}</span>
									<span class="count">&nbsp;{{ $countCatPosts->get($iCat->tid)->total or 0 }}</span>
								</a>
							@endif
						</li>
					@endforeach
                    @endif
				</ul>
			</div>
            
            
            
            @if (isset($cat))
    
        		<?php $parentId = ($cat->parent_id == 0) ? $cat->tid : $cat->parent_id; ?>
                <!-- SubCategory -->
				<div id="subCatsList" class="categories-list list-filter">
					<h5 class="list-title">
                        <strong><a href="#"><i class="fa fa-angle-left"></i> {{ t('Others Categories') }}</a></strong>
                    </h5>
					<ul class="list-unstyled">
						<li>
                            @if ($cats->has($parentId))
								<?php $attr = ['countryCode' => config('country.icode'), 'catSlug' => $cats->get($parentId)->slug]; ?>
								<a href="{{ lurl(trans('routes.v-search-cat', $attr), $attr) }}" title="{{ $cats->get($parentId)->name }}">
									<span class="title"><strong>{{ $cats->get($parentId)->name }}</strong>
									</span><span class="count">&nbsp;{{ $countCatPosts->get($parentId)->total or 0 }}</span>
								</a>
                            @endif
							<ul class="list-unstyled ">
							    <!--long-list-->
                                @if ($cats->groupBy('parent_id')->has($parentId))
								@foreach ($cats->groupBy('parent_id')->get($parentId) as $iSubCat)
                                    @continue(!$cats->has($iSubCat->parent_id))
									<li>
										<?php $attr = [
											'countryCode' => config('country.icode'),
											'catSlug'     => $cats->get($iSubCat->parent_id)->slug,
											'subCatSlug'  => $iSubCat->slug
										]; ?>
										@if ((isset($uriPathSubCatSlug) and $uriPathSubCatSlug == $iSubCat->slug) or (Request::input('sc') == $iSubCat->tid))
											<strong>
												<a href="{{ lurl(trans('routes.v-search-subCat', $attr), $attr) }}" title="{{ $iSubCat->name }}">
													{{ str_limit($iSubCat->name, 100) }}
													<span class="count">({{ $countSubCatPosts->get($iSubCat->tid)->total or 0 }})</span>
												</a>
											</strong>
										@else
											<a href="{{ lurl(trans('routes.v-search-subCat', $attr), $attr) }}" title="{{ $iSubCat->name }}">
												{{ str_limit($iSubCat->name, 100) }}
                                                <span class="count">({{ $countSubCatPosts->get($iSubCat->tid)->total or 0 }})</span>
											</a>
										@endif
										
										
										<!-- qedama -->
										
										
									
									
									
									
									  @if ($cats->groupBy('parent_id')->has($iSubCat->id) and config('country.icode')=="en")
								@foreach ($cats->groupBy('parent_id')->get($iSubCat->id) as $iSubCat2)
                                    
                                    <ul class="list-unstyled ">
									<li>
										<?php $attr = [
											'countryCode' => config('country.icode'),
											'catSlug'     => $cats->get($iSubCat2->parent_id)->slug,
											'subCatSlug'  => $iSubCat2->slug
										]; ?>
										@if ((isset($uriPathSubCatSlug) and $uriPathSubCatSlug == $iSubCat2->slug) or (Request::input('sc') == $iSubCat2->tid))
											<strong>
												<a href="{{ lurl(trans('routes.v-search-subCat', $attr), $attr) }}" title="{{ $iSubCat2->name }}">
													{{ str_limit($iSubCat2->name, 100) }}
													<span class="count">({{ $countSubCatPosts->get($iSubCat2->tid)->total or 0 }})</span>
												</a>
											</strong>
										@else
											<a href="{{ lurl(trans('routes.v-search-subCat', $attr), $attr) }}" title="{{ $iSubCat2->name }}">
												{{ str_limit($iSubCat2->name, 100) }}
                                                <span class="count">({{ $countSubCatPosts->get($iSubCat2->tid)->total or 0 }})</span>
											</a>
										@endif
										
										
									
										    	
										
										
										
									</li>
									
									</ul>
								@endforeach
                                @endif
									
									
										    	
										    	
										    	
							    @if ($cats->groupBy('parent_id')->has($iSubCat->translation_of) )
								@foreach ($cats->groupBy('parent_id')->get($iSubCat->translation_of) as $iSubCat2)
                                    
                                    <ul class="list-unstyled ">
									<li>
										<?php $attr = [
											'countryCode' => config('country.icode'),
											'catSlug'     => $cats->get($iSubCat2->parent_id)->slug,
											'subCatSlug'  => $iSubCat2->slug
										]; ?>
										@if ((isset($uriPathSubCatSlug) and $uriPathSubCatSlug == $iSubCat2->slug) or (Request::input('sc') == $iSubCat2->tid))
											<strong>
												<a href="{{ lurl(trans('routes.v-search-subCat', $attr), $attr) }}" title="{{ $iSubCat2->name }}">
													{{ str_limit($iSubCat2->name, 100) }}
													<span class="count">({{ $countSubCatPosts->get($iSubCat2->tid)->total or 0 }})</span>
												</a>
											</strong>
										@else
											<a href="{{ lurl(trans('routes.v-search-subCat', $attr), $attr) }}" title="{{ $iSubCat2->name }}">
												{{ str_limit($iSubCat2->name, 100) }}
                                                <span class="count">({{ $countSubCatPosts->get($iSubCat2->tid)->total or 0 }})</span>
											</a>
										@endif
										
										
									
										    	
										
										
										
									</li>
									
									</ul>
								@endforeach
                                @endif
										    	
										    		<!-- qedama -->
										    	
										
										
										
									</li>
								@endforeach
                                @endif
							</ul>
						</li>
					</ul>
				</div>
            
            
                @if (!in_array($cat->type, ['non-salable']))
                <!-- Price -->
                <div class="locations-list list-filter">
                    <h5 class="list-title"><strong><a href="#">{{ (!in_array($cat->type, ['job-offer', 'job-search'])) ? t('Price range') : t('Salary range') }}</a></strong></h5>
                    <form role="form" class="form-inline" action="{{ $fullUrlNoParams }}" method="GET">
						{!! csrf_field() !!}
                        @foreach(Request::except(['minPrice', 'maxPrice', '_token']) as $key => $value)
                            @if (is_array($value))
                                @foreach($value as $k => $v)
									@if (is_array($v))
										@foreach($v as $ik => $iv)
											@continue(is_array($iv))
											<input type="hidden" name="{{ $key.'['.$k.']['.$ik.']' }}" value="{{ $iv }}">
										@endforeach
									@else
                                    	<input type="hidden" name="{{ $key.'['.$k.']' }}" value="{{ $v }}">
									@endif
                                @endforeach
                            @else
                                <input type="hidden" name="{{ $key }}" value="{{ $value }}">
                            @endif
                        @endforeach
                        <div class="form-group col-sm-4 no-padding">
                            <input type="text" placeholder="0" id="minPrice" name="minPrice" class="form-control" value="{{ Request::get('minPrice') }}">
                        </div>
                        <div style="margin-top: 10px;" class="form-group col-sm-1 no-padding text-center hidden-xs to-size-arabic"> - </div>
                        <div  class="form-group col-sm-4 no-padding">
                            <input type="text" placeholder="" id="maxPrice" name="maxPrice" class="form-control" value="{{ Request::get('maxPrice') }}">
                        </div>
                        <div class="form-group col-sm-3 no-padding">
                            <button class="btn btn-default pull-right btn-block-xs" type="submit">{{ t('GO') }}</button>
                        </div>
                    </form>
                    <div style="clear:both"></div>
                </div>
                @endif
				
		
				<?php $style = 'style="display: none;"'; ?>
			@else
			
			
			<div class="locations-list list-filter">
                    <h5 class="list-title"><strong><a href="#">{{ t('Price range') }}</a></strong></h5>
                    <form role="form" class="form-inline" action="{{ $fullUrlNoParams }}" method="GET">
						<input name="_token" value="{{ csrf_token() }}" type="hidden">
                       <div class="form-group col-sm-4 no-padding">
                            <input placeholder="0" id="minPrice" name="minPrice" class="form-control" value="{{ Request::get('minPrice') }}" type="text">
                        </div>
                        <div style="margin-top: 10px;" class="form-group col-sm-1 no-padding text-center hidden-xs to-size-arabic"> - </div>
                        <div class="form-group col-sm-4 no-padding">
                            <input placeholder="" id="maxPrice" name="maxPrice" class="form-control" value="{{ Request::get('maxPrice') }}" type="text">
                        </div>
                        <div class="form-group col-sm-3 no-padding">
                            <button class="btn btn-default pull-right btn-block-xs" type="submit">{{ t('GO') }}</button>
                        </div>
                    </form>
                    <div style="clear:both"></div>
                </div>
                
			@endif
			
        
         
            
            
            
            @include('search.inc.fields')
            
             <div class="locations-list list-filter">
                    <h5 class="list-title"><strong><a href="#">{{t('Distance within')}}</a></strong></h5>
                            	<select id="orderBySideBar" class="selecter" data-style="btn-select" >
								    <?php
								    $distance_array = array("10", "25", "50", "75","100","150","200","250","400","600","800","1000","3000","10000");
								    ?>
									@if (isset($isCitySearch) and $isCitySearch and \App\Helpers\DBTool::checkIfMySQLFunctionExists(config('larapen.core.distanceCalculationFormula')))
										@for($iDist = 0; $iDist <= config('settings.listing.search_distance_max', 500); $iDist += config('settings.listing.search_distance_interval', 50))
										<?php
										if (in_array($iDist, $distance_array))
										{
										?>
											<option{{ (Request::get('distance', config('settings.listing.search_distance_default', 100))==$iDist) ? ' selected="selected"' : '' }}
													value="{!! qsurl($fullUrlNoParams, array_merge(Request::except('distance'), ['distance' => $iDist])) !!}">
												{{ t('Around :distance :unit', ['distance' => $iDist, 'unit' => unitOfLength()]) }}
											</option>
										<?php 
										}
										?>	
										@endfor
									@else
										@for($iDist = 0; $iDist <= config('settings.listing.search_distance_max', 500); $iDist += config('settings.listing.search_distance_interval', 50))
										<?php
										if (in_array($iDist, $distance_array))
										{
										?>
											<option{{ (Request::get('distance', config('settings.listing.search_distance_default', 100))==$iDist) ? ' selected="selected"' : '' }}
													value="{!! qsurl($fullUrlNoParams, array_merge(Request::except('distance'), ['distance' => $iDist])) !!}">
												{{ t('Around :distance :unit', ['distance' => $iDist, 'unit' => unitOfLength()]) }}
											</option>
									<?php
									    }
									?>
									
										@endfor
									@endif
								</select>
								
                    <div style="clear:both"></div>
                </div>
            
            
            
            
            
            
            
            
            
            
            
            <!-- City -->
			<div class="locations-list list-filter" style="display:none;">
				<h5 class="list-title"><strong><a href="#">{{ t('Locations') }}</a></strong></h5>
				<ul class="browse-list list-unstyled long-list">
                    @if (isset($cities) and $cities->count() > 0)
						@foreach ($cities as $city)
							<?php
								$attr = ['countryCode' => config('country.icode')];
								$fullUrlLocation = lurl(trans('routes.v-search', $attr), $attr);
								$locationParams = [
									'l'  => $city->id,
									'r'  => '',
									'c'  => (isset($cat)) ? $cat->tid : '',
									'sc' => (isset($subCat)) ? $subCat->tid : '',
								];
							?>
							<li>
								@if ((isset($uriPathCityId) and $uriPathCityId == $city->id) or (Request::input('l')==$city->id))
									<strong>
										<a href="{!! qsurl($fullUrlLocation, array_merge(Request::except(array_keys($locationParams)), $locationParams)) !!}" title="{{ $city->name }}">
											{{ $city->name }}
										</a>
									</strong>
								@else
									<a href="{!! qsurl($fullUrlLocation, array_merge(Request::except(array_keys($locationParams)), $locationParams)) !!}" title="{{ $city->name }}">
										{{ $city->name }}
									</a>
								@endif
							</li>
						@endforeach
                    @endif
				</ul>
			</div>

			<div style="clear:both"></div>
		</div>
	</aside>

</div>

@section('after_scripts')
    @parent
    <script>
        var baseUrl = '{{ $fullUrlNoParams }}';
        
        $(document).ready(function ()
        {
            $('input[type=radio][name=postedDate]').click(function() {
                var postedQueryString = $('#postedQueryString').val();
				
                if (postedQueryString != '') {
                    postedQueryString = postedQueryString + '&';
                }
                postedQueryString = postedQueryString + 'postedDate=' + $(this).val();
                
                var searchUrl = baseUrl + '?' + postedQueryString;
				redirect(searchUrl);
            });
        });
    </script>
@endsection