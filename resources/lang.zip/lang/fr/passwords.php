<?php

return [
    
    /*
    |--------------------------------------------------------------------------
    | Password Reminder Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'Les mots de passe doivent contenir au moins six caractères et doivent être identiques.',
    'reset'    => 'Votre mot de passe a été réinitialisé !',
    'sent'     => 'Nous vous avons envoyé le lien de réinitialisation du mot de passe par email!',
    'token'    => "Ce jeton de réinitialisation du mot de passe n'est pas valide.",
    'user'     => "Nous ne trouvons aucun utilisateur avec cette adresse email.",

];
